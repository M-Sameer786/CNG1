import {
  boolean,
  doublePrecision,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("cng_users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("user"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const stationsTable = pgTable("cng_stations", {
  id: serial("id").primaryKey(),
  stationName: text("station_name").notNull(),
  address: text("address").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  phone: text("phone").notNull(),
  openingTime: text("opening_time").notNull(),
  closingTime: text("closing_time").notNull(),
  availability: text("availability").notNull().default("NOT_AVAILABLE"),
  stockKg: doublePrecision("stock_kg"),
  pricePerKg: doublePrecision("price_per_kg"),
  discountPercent: doublePrecision("discount_percent").notNull().default(0),
  availabilityNote: text("availability_note"),
  availabilityUpdatedAt: timestamp("availability_updated_at", {
    withTimezone: true,
  }),
  availabilityUpdatedById: integer("availability_updated_by_id").references(
    () => usersTable.id,
    { onDelete: "set null" },
  ),
  supplierId: integer("supplier_id").references(() => usersTable.id, {
    onDelete: "set null",
  }),
  rating: doublePrecision("rating").notNull().default(0),
  demoData: boolean("demo_data").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviewsTable = pgTable("cng_reviews", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  stationId: integer("station_id")
    .notNull()
    .references(() => stationsTable.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(),
  review: text("review").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const availabilityUpdatesTable = pgTable("cng_availability_updates", {
  id: serial("id").primaryKey(),
  stationId: integer("station_id")
    .notNull()
    .references(() => stationsTable.id, { onDelete: "cascade" }),
  availability: text("availability").notNull(),
  stockKg: doublePrecision("stock_kg"),
  pricePerKg: doublePrecision("price_per_kg"),
  availabilityNote: text("availability_note"),
  updatedBy: integer("updated_by")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const authSessionsTable = pgTable("cng_auth_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => usersTable.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const vehiclesTable = pgTable(
  "cng_vehicles",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    registrationNumber: text("registration_number").notNull(),
    make: text("make").notNull(),
    model: text("model").notNull(),
    category: text("category").notNull(),
    fuelType: text("fuel_type").notNull(),
    cngFitment: text("cng_fitment").notNull(),
    nickname: text("nickname"),
    isDefault: boolean("is_default").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    registrationUnique: uniqueIndex("cng_vehicles_registration_unique").on(
      sql`lower(${table.registrationNumber})`,
    ),
    userIndex: index("cng_vehicles_user_idx").on(table.userId),
  }),
);

export const fuelTransactionsTable = pgTable(
  "cng_fuel_transactions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => usersTable.id, { onDelete: "cascade" }),
    stationId: integer("station_id")
      .notNull()
      .references(() => stationsTable.id, { onDelete: "restrict" }),
    vehicleId: integer("vehicle_id")
      .notNull()
      .references(() => vehiclesTable.id, { onDelete: "restrict" }),
    idempotencyKey: text("idempotency_key").notNull(),
    actualKg: doublePrecision("actual_kg"),
    unitPrice: doublePrecision("unit_price"),
    discountPercent: doublePrecision("discount_percent").notNull().default(0),
    totalAmount: doublePrecision("total_amount"),
    status: text("status").notNull().default("awaiting_confirmation"),
    paymentStatus: text("payment_status").notNull().default("not_started"),
    paymentReference: text("payment_reference"),
    stockDeducted: boolean("stock_deducted").notNull().default(false),
    confirmedById: integer("confirmed_by_id").references(() => usersTable.id, {
      onDelete: "set null",
    }),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
    paymentVerifiedAt: timestamp("payment_verified_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    userRequestUnique: uniqueIndex("cng_fuel_user_request_unique").on(
      table.userId,
      table.idempotencyKey,
    ),
    userCreatedIndex: index("cng_fuel_user_created_idx").on(
      table.userId,
      table.createdAt,
    ),
    stationStatusIndex: index("cng_fuel_station_status_idx").on(
      table.stationId,
      table.status,
    ),
  }),
);

export const insertUserSchema = createInsertSchema(usersTable).omit({
  id: true,
  createdAt: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;

export const insertStationSchema = createInsertSchema(stationsTable).omit({
  id: true,
  rating: true,
  demoData: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertStation = z.infer<typeof insertStationSchema>;
export type Station = typeof stationsTable.$inferSelect;

export const insertReviewSchema = createInsertSchema(reviewsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviewsTable.$inferSelect;