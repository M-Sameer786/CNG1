ALTER TABLE cng_stations
  ADD COLUMN IF NOT EXISTS discount_percent double precision NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS cng_vehicles (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES cng_users(id) ON DELETE CASCADE,
  registration_number text NOT NULL,
  make text NOT NULL,
  model text NOT NULL,
  category text NOT NULL,
  fuel_type text NOT NULL,
  cng_fitment text NOT NULL,
  nickname text,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS cng_vehicles_registration_unique
  ON cng_vehicles (lower(registration_number));
CREATE INDEX IF NOT EXISTS cng_vehicles_user_idx
  ON cng_vehicles (user_id);

CREATE TABLE IF NOT EXISTS cng_fuel_transactions (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES cng_users(id) ON DELETE CASCADE,
  station_id integer NOT NULL REFERENCES cng_stations(id) ON DELETE RESTRICT,
  vehicle_id integer NOT NULL REFERENCES cng_vehicles(id) ON DELETE RESTRICT,
  idempotency_key text NOT NULL,
  actual_kg double precision,
  unit_price double precision,
  discount_percent double precision NOT NULL DEFAULT 0,
  total_amount double precision,
  status text NOT NULL DEFAULT 'awaiting_confirmation',
  payment_status text NOT NULL DEFAULT 'not_started',
  payment_reference text,
  stock_deducted boolean NOT NULL DEFAULT false,
  confirmed_by_id integer REFERENCES cng_users(id) ON DELETE SET NULL,
  confirmed_at timestamptz,
  payment_verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS cng_fuel_user_request_unique
  ON cng_fuel_transactions (user_id, idempotency_key);
CREATE INDEX IF NOT EXISTS cng_fuel_user_created_idx
  ON cng_fuel_transactions (user_id, created_at);
CREATE INDEX IF NOT EXISTS cng_fuel_station_status_idx
  ON cng_fuel_transactions (station_id, status);
