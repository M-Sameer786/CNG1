@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo ERROR: Node.js is not installed or not on PATH.& pause & exit /b 1)
where pnpm >nul 2>nul || (echo ERROR: pnpm is missing. Run npm install -g pnpm.& pause & exit /b 1)
if not exist .env (echo ERROR: .env is missing. Run SETUP-WINDOWS.bat first.& pause & exit /b 1)
echo Starting CNGConnect. Keep this window open.
pnpm dev
pause
