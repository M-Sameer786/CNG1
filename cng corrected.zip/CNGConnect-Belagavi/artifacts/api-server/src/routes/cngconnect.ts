import {
  createHmac,
  createHash,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  and,
  avg,
  count,
  desc,
  eq,
  gte,
  ilike,
  or,
} from "drizzle-orm";
import { z } from "zod/v4";
import {
  authSessionsTable,
  availabilityUpdatesTable,
  db,
  fuelTransactionsTable,
  reviewsTable,
  stationsTable,
  usersTable,
  vehiclesTable,
} from "@workspace/db";
import {
  CreateManagedUserBody,
  CreateStationBody,
  CreateStationReviewParams,
  CreateStationReviewBody,
  DeleteReviewParams,
  DeleteStationParams,
  GetRecommendationQueryParams,
  GetStationParams,
  ListStationsQueryParams,
  LoginUserBody,
  RegisterUserBody,
  UpdateAvailabilityBody,
  UpdateAvailabilityParams,
  UpdateStationBody,
  UpdateStationParams,
  UpdateSupplierAvailabilityBody,
  UpdateSupplierAvailabilityParams,
  CreateStationResponse,
  CreateStationReviewResponse,
  CreateManagedUserResponse,
  DeleteReviewResponse,
  DeleteStationResponse,
  GetAdminSummaryResponse,
  GetCurrentUserResponse,
  GetRecommendationResponse,
  GetStationResponse,
  ListAdminActivityResponse,
  ListAdminReviewsResponse,
  ListAdminStationsResponse,
  ListStationReviewsResponse,
  ListStationsResponse,
  ListSupplierStationsResponse,
  ListUsersResponse,
  LoginUserResponse,
  RegisterUserResponse,
  UpdateAvailabilityResponse,
  UpdateStationResponse,
  UpdateSupplierAvailabilityResponse,
} from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const SESSION_COOKIE = "cng_session";
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const STALE_AFTER_MS = 30 * 60 * 1000;
const availabilityClients = new Set<Response>();
// Local test-mode signing key only; production payments must use a real provider.
const TEST_PAYMENT_SECRET = randomBytes(32).toString("hex");

type Role = "user" | "supplier" | "admin";
type Availability = "AVAILABLE" | "LOW" | "NOT_AVAILABLE";
type SessionUser = {
  id: number;
  name: string;
  email: string;
  role: Role;
};
type AvailabilityPayload = {
  availability: Availability;
  stockKg: number | null;
  pricePerKg: number | null;
  availabilityNote: string;
};

const DEMO_LOW_STOCK_THRESHOLD_KG = 100;
const DEMO_STOCK_NOTE =
  "Illustrative demo stock only; this is not a live station report.";

function availabilityFromStock(stockKg: number | null | undefined): Availability | null {
  if (stockKg == null || !Number.isFinite(stockKg)) return null;
  if (stockKg <= 0) return "NOT_AVAILABLE";
  return stockKg <= DEMO_LOW_STOCK_THRESHOLD_KG ? "LOW" : "AVAILABLE";
}

const demoStations = [
  {
    stationName: "Belagavi (IOCL) — Shri Dattopant Automobiles",
    address: "IOCL Bunk Shree Dattopant Automobile, R S NO 1056/2, Gandhi Nagar, Belagavi-590016",
    latitude: 15.8500,
    longitude: 74.5000,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "23:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "Belagavi (IOCL) — M/s Anushree Petroleum",
    address: "M/s Anushree Petroleums, Sy No: 349-5/1, Khanapur Road, Udyambag, Belagavi-590008",
    latitude: 15.8230,
    longitude: 74.5010,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "23:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "Belgaum (BPCL) — Barde Road Lines",
    address: "NH-04 HIGHWAY, KANGRALI",
    latitude: 15.92066,
    longitude: 74.52551,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "23:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "Belgaum (IOCL) — Shree Mahalaxmi Petroleum",
    address: "AIRPORT ROAD, MARUTHI NAGAR, BELGAUM",
    latitude: 15.8656,
    longitude: 74.6185,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "23:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "OM SAI KRISHNA PETROLEUM",
    address: "41-5 Vidyagiri, Bauxite Road, Azam Nagar, Belagavi-590010",
    latitude: 15.8400,
    longitude: 74.4900,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "22:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "Megha City Gas Distribution Pvt Ltd",
    address: "84/4B, Basavannakolla Village, Yamanpur, behind GAIL Office, Belagavi",
    latitude: 15.9000,
    longitude: 74.5400,
    phone: "18001231803",
    openingTime: "00:00",
    closingTime: "23:59",
    availability: "AVAILABLE",
  },
  {
    stationName: "Kiwad Petroleum",
    address: "Rs No. 168A, Chikodi, Karnataka-591201",
    latitude: 16.4280,
    longitude: 74.5850,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "22:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "M/s M.P. KARIKAZI",
    address: "Hukeri, Belagavi District, Karnataka",
    latitude: 16.2300,
    longitude: 74.6000,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "22:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "M/S PRAKASH PETROLEUM",
    address: "NH-04, KADROLLI, Belagavi District, Karnataka",
    latitude: 15.68456,
    longitude: 74.71772,
    phone: "+919986336234",
    openingTime: "00:00",
    closingTime: "23:59",
    availability: "AVAILABLE",
  },
  {
    stationName: "M/s Swayambhu Hanuman Petroleum",
    address: "NH-478AA, Belagavi District, Karnataka",
    latitude: 16.0000,
    longitude: 74.8000,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "22:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "M/s Shree Renuka Highway Petroleum",
    address: "No. 220/2, Poona Bangalore NH-4, Bagewadi",
    latitude: 16.17187,
    longitude: 74.52188,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "22:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "Butali Petroleum",
    address: "Survey No. 597/A/2A, Charmalaya, Athani, Belagavi District",
    latitude: 16.7200,
    longitude: 75.0000,
    phone: "Not provided",
    openingTime: "06:00",
    closingTime: "22:00",
    availability: "AVAILABLE",
  },
  {
    stationName: "BP KOGNOLLI-BPCL",
    address: "Survey 446, Kognolli Village",
    latitude: 16.54641,
    longitude: 74.31851,
    phone: "Not provided",
    openingTime: "00:00",
    closingTime: "23:59",
    availability: "AVAILABLE",
  },
  {
    stationName: "M/s Rameshwar Petroleum",
    address: "Survey No: 432/A, Honga, Belagavi District, Karnataka",
    latitude: 15.97552,
    longitude: 74.50962,
    phone: "Not provided",
    openingTime: "00:00",
    closingTime: "23:59",
    availability: "AVAILABLE",
  },
  {
    stationName: "Padmavathi Petroleum",
    address: "Survey No. 31/2, Miraj Road, Kagwad, Belagavi-591223",
    latitude: 16.5800,
    longitude: 74.7700,
    phone: "+918548066867",
    openingTime: "00:00",
    closingTime: "23:59",
    availability: "AVAILABLE",
  },
];

const demoStockKgValues = [
  245, 48, 150, 75, 0, 320, 42, 215, 56, 130, 84, 290, 94, 18, 176,
];

if (demoStockKgValues.length !== demoStations.length) {
  throw new Error("Every demo station must have a sample stock value.");
}

const demoStationsWithStock = demoStations.map((station, index) => {
  const stockKg = demoStockKgValues[index];
  if (stockKg === undefined) {
    throw new Error(`Missing demo stock value for ${station.stationName}.`);
  }
  return {
    ...station,
    demoData: true,
    stockKg,
    availability: availabilityFromStock(stockKg) ?? station.availability,
    availabilityNote: DEMO_STOCK_NOTE,
  };
});

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const actual = scryptSync(password, salt, 64);
  const expectedBytes = Buffer.from(expected, "hex");
  return (
    actual.length === expectedBytes.length &&
    timingSafeEqual(actual, expectedBytes)
  );
}

function publicUser(user: typeof usersTable.$inferSelect): SessionUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role as Role,
  };
}

function tokenDigest(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

async function getSessionUser(req: Request): Promise<SessionUser | undefined> {
  const token = req.cookies?.[SESSION_COOKIE] as string | undefined;
  if (!token) return undefined;
  const [session] = await db
    .select({ user: usersTable, expiresAt: authSessionsTable.expiresAt })
    .from(authSessionsTable)
    .innerJoin(usersTable, eq(authSessionsTable.userId, usersTable.id))
    .where(eq(authSessionsTable.tokenHash, tokenDigest(token)))
    .limit(1);
  if (!session || session.expiresAt.getTime() <= Date.now()) {
    await db
      .delete(authSessionsTable)
      .where(eq(authSessionsTable.tokenHash, tokenDigest(token)));
    return undefined;
  }
  return publicUser(session.user);
}

async function requireUser(
  req: Request,
  res: Response,
): Promise<SessionUser | undefined> {
  const user = await getSessionUser(req);
  if (!user) {
    res.status(401).json({ error: "Please sign in to continue." });
    return undefined;
  }
  return user;
}

async function requireRole(
  req: Request,
  res: Response,
  role: Role,
): Promise<SessionUser | undefined> {
  const user = await requireUser(req, res);
  if (user && user.role !== role) {
    res.status(403).json({ error: `${role} access is required.` });
    return undefined;
  }
  return user;
}

async function startSession(
  res: Response,
  user: typeof usersTable.$inferSelect,
): Promise<SessionUser> {
  const token = randomBytes(32).toString("base64url");
  await db.insert(authSessionsTable).values({
    tokenHash: tokenDigest(token),
    userId: user.id,
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  });
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_MS,
  });
  return publicUser(user);
}

async function ensureDemoAccount(
  name: string,
  email: string,
  password: string,
  role: Role,
): Promise<number> {
  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(ilike(usersTable.email, email))
    .limit(1);
  if (existing) return existing.id;
  const [created] = await db
    .insert(usersTable)
    .values({ name, email, passwordHash: hashPassword(password), role })
    .returning({ id: usersTable.id });
  if (!created) throw new Error(`Unable to create the ${role} demo account`);
  return created.id;
}

async function initializeDemoData(): Promise<void> {
  let adminId: number | undefined;
  let supplierId: number | undefined;
  if (process.env.NODE_ENV === "production") {
    const initialAdminEmail = process.env.CNGCONNECT_INITIAL_ADMIN_EMAIL?.trim();
    const initialAdminPassword = process.env.CNGCONNECT_INITIAL_ADMIN_PASSWORD;
    if (
      !initialAdminEmail ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(initialAdminEmail) ||
      !initialAdminPassword ||
      initialAdminPassword.length < 8
    ) {
      throw new Error(
        "Production startup requires a valid CNGCONNECT_INITIAL_ADMIN_EMAIL and a CNGCONNECT_INITIAL_ADMIN_PASSWORD of at least 8 characters.",
      );
    }
    adminId = await ensureDemoAccount(
      "CNGConnect Administrator",
      initialAdminEmail,
      initialAdminPassword,
      "admin",
    );
  } else {
    adminId = await ensureDemoAccount(
      "CNGConnect Administrator",
      "admin@cngconnect.demo",
      "Belagavi@123",
      "admin",
    );
    await ensureDemoAccount(
      "Demo Driver",
      "driver@cngconnect.demo",
      "Driver@123",
      "user",
    );
    supplierId = await ensureDemoAccount(
      "Megha Gas Supplier",
      "supplier@meghagas.demo",
      "MeghaGas@123",
      "supplier",
    );
  }
  // Add each project station if it is not already present.
  // This makes the station list update even when an existing local database is reused.
  for (const station of demoStationsWithStock) {
    const [existingStation] = await db
      .select({
        id: stationsTable.id,
        demoData: stationsTable.demoData,
        stockKg: stationsTable.stockKg,
        availability: stationsTable.availability,
        availabilityNote: stationsTable.availabilityNote,
      })
      .from(stationsTable)
      .where(eq(stationsTable.stationName, station.stationName))
      .limit(1);

    if (existingStation) {
      if (existingStation.demoData) {
        const stockKg = existingStation.stockKg ?? station.stockKg;
        const availability =
          availabilityFromStock(stockKg) ?? station.availability;
        const needsDemoNote =
          existingStation.stockKg == null &&
          !existingStation.availabilityNote;
        if (
          existingStation.stockKg == null ||
          existingStation.availability !== availability ||
          needsDemoNote
        ) {
          await db
            .update(stationsTable)
            .set({
              stockKg,
              availability,
              ...(needsDemoNote ? { availabilityNote: DEMO_STOCK_NOTE } : {}),
              updatedAt: new Date(),
            })
            .where(eq(stationsTable.id, existingStation.id));
        }
      }
      continue;
    }

    const [insertedStation] = await db
      .insert(stationsTable)
      .values(station)
      .returning({ id: stationsTable.id });

    if (insertedStation && (supplierId !== undefined || adminId !== undefined)) {
      await db
        .update(stationsTable)
        .set({
          ...(supplierId !== undefined ? { supplierId } : {}),
          ...(adminId !== undefined ? { availabilityUpdatedById: adminId } : {}),
        })
        .where(eq(stationsTable.id, insertedStation.id));
    }
  }
}

const ready = initializeDemoData();

router.use((_req, res, next) => {
  ready.then(
    () => next(),
    (error: unknown) => {
      logger.error({ err: error }, "CNGConnect database initialization failed");
      res.status(503).json({ error: "The station service is not ready." });
    },
  );
});

function haversineKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const radians = (value: number) => (value * Math.PI) / 180;
  const dLat = radians(lat2 - lat1);
  const dLon = radians(lon2 - lon1);
  const value =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(radians(lat1)) *
      Math.cos(radians(lat2)) *
      Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

async function stationView(
  station: typeof stationsTable.$inferSelect,
  latitude?: number,
  longitude?: number,
) {
  const demoAvailability =
    station.demoData ? availabilityFromStock(station.stockKg) : null;
  const [[reviewCount], supplier, updatedBy] = await Promise.all([
    db
      .select({ value: count() })
      .from(reviewsTable)
      .where(eq(reviewsTable.stationId, station.id)),
    station.supplierId
      ? db
          .select({ name: usersTable.name })
          .from(usersTable)
          .where(eq(usersTable.id, station.supplierId))
          .limit(1)
      : Promise.resolve([]),
    station.availabilityUpdatedById
      ? db
          .select({ name: usersTable.name })
          .from(usersTable)
          .where(eq(usersTable.id, station.availabilityUpdatedById))
          .limit(1)
      : Promise.resolve([]),
  ]);
  return {
    id: station.id,
    stationName: station.stationName,
    address: station.address,
    latitude: station.latitude,
    longitude: station.longitude,
    phone: station.phone,
    openingTime: station.openingTime,
    closingTime: station.closingTime,
    availability: demoAvailability ?? (station.availability as Availability),
    stockKg: station.stockKg,
    pricePerKg: station.pricePerKg,
    discountPercent: station.discountPercent,
    availabilityNote: station.availabilityNote,
    availabilityUpdatedAt: station.availabilityUpdatedAt,
    availabilityUpdatedBy: updatedBy[0]?.name ?? null,
    supplierId: station.supplierId,
    supplierName: supplier[0]?.name ?? null,
    rating: Number(station.rating),
    reviewCount: Number(reviewCount?.value ?? 0),
    distanceKm:
      latitude !== undefined && longitude !== undefined
        ? Number(
            haversineKm(
              latitude,
              longitude,
              station.latitude,
              station.longitude,
            ).toFixed(1),
          )
        : null,
    demoData: station.demoData,
  };
}

async function refreshRating(stationId: number): Promise<void> {
  const [result] = await db
    .select({ value: avg(reviewsTable.rating) })
    .from(reviewsTable)
    .where(eq(reviewsTable.stationId, stationId));
  await db
    .update(stationsTable)
    .set({
      rating: Number(Number(result?.value ?? 0).toFixed(1)),
      updatedAt: new Date(),
    })
    .where(eq(stationsTable.id, stationId));
}

function broadcastAvailability(station: Awaited<ReturnType<typeof stationView>>): void {
  const event = `data: ${JSON.stringify({
    stationId: station.id,
    availability: station.availability,
    availabilityUpdatedAt: station.availabilityUpdatedAt,
  })}\n\n`;
  for (const client of availabilityClients) {
    try {
      client.write(event);
    } catch {
      availabilityClients.delete(client);
    }
  }
}

async function applyAvailability(
  stationId: number,
  userId: number,
  input: AvailabilityPayload,
): Promise<Awaited<ReturnType<typeof stationView>> | undefined> {
  const [currentStation] = await db
    .select({ demoData: stationsTable.demoData })
    .from(stationsTable)
    .where(eq(stationsTable.id, stationId))
    .limit(1);
  if (!currentStation) return undefined;

  const appliedInput = {
    ...input,
    availability:
      currentStation.demoData && input.stockKg !== null
        ? availabilityFromStock(input.stockKg) ?? input.availability
        : input.availability,
  };
  const updatedAt = new Date();
  const [station] = await db
    .update(stationsTable)
    .set({
      ...appliedInput,
      availabilityUpdatedAt: updatedAt,
      availabilityUpdatedById: userId,
      updatedAt,
    })
    .where(eq(stationsTable.id, stationId))
    .returning();
  if (!station) return undefined;
  await db.insert(availabilityUpdatesTable).values({
    stationId,
    ...appliedInput,
    updatedBy: userId,
    updatedAt,
  });
  const view = await stationView(station);
  broadcastAvailability(view);
  return view;
}

router.get("/auth/me", async (req, res): Promise<void> => {
  const user = await getSessionUser(req);
  res.json(
    GetCurrentUserResponse.parse({
      authenticated: Boolean(user),
      user: user ?? null,
    }),
  );
});

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const email = parsed.data.email.trim().toLowerCase();
  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, email))
    .limit(1);
  if (existing) {
    res.status(409).json({ error: "An account already uses that email." });
    return;
  }
  const [user] = await db
    .insert(usersTable)
    .values({
      name: parsed.data.name.trim(),
      email,
      passwordHash: hashPassword(parsed.data.password),
      role: "user",
    })
    .returning();
  if (!user) {
    res.status(500).json({ error: "Could not create your account." });
    return;
  }
  res.status(201).json(RegisterUserResponse.parse(await startSession(res, user)));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [user] = await db
    .select()
    .from(usersTable)
    .where(ilike(usersTable.email, parsed.data.email.trim()))
    .limit(1);
  if (!user || !verifyPassword(parsed.data.password, user.passwordHash)) {
    res.status(401).json({ error: "Email or password is incorrect." });
    return;
  }
  res.json(LoginUserResponse.parse(await startSession(res, user)));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const token = req.cookies?.[SESSION_COOKIE] as string | undefined;
  if (token) {
    await db
      .delete(authSessionsTable)
      .where(eq(authSessionsTable.tokenHash, tokenDigest(token)));
  }
  res.clearCookie(SESSION_COOKIE, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
  });
  res.sendStatus(204);
});

router.get("/stations", async (req, res): Promise<void> => {
  const parsed = ListStationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, availability, latitude, longitude, sort } = parsed.data;
  const filters = [];
  if (search?.trim()) {
    const term = `%${search.trim()}%`;
    filters.push(
      or(
        ilike(stationsTable.stationName, term),
        ilike(stationsTable.address, term),
      ),
    );
  }
  if (availability) filters.push(eq(stationsTable.availability, availability));
  const rows = await db
    .select()
    .from(stationsTable)
    .where(filters.length ? and(...filters) : undefined);
  const results = await Promise.all(
    rows.map((row) => stationView(row, latitude, longitude)),
  );
  if (sort === "rating") results.sort((a, b) => b.rating - a.rating);
  else if (sort === "name")
    results.sort((a, b) => a.stationName.localeCompare(b.stationName));
  else if (latitude !== undefined && longitude !== undefined)
    results.sort(
      (a, b) => (a.distanceKm ?? Infinity) - (b.distanceKm ?? Infinity),
    );
  res.json(ListStationsResponse.parse(results));
});

router.get("/stations/:stationId", async (req, res): Promise<void> => {
  const params = GetStationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [station] = await db
    .select()
    .from(stationsTable)
    .where(eq(stationsTable.id, params.data.stationId))
    .limit(1);
  if (!station) {
    res.status(404).json({ error: "Station not found." });
    return;
  }
  res.json(GetStationResponse.parse(await stationView(station)));
});

router.get(
  "/stations/:stationId/reviews",
  async (req, res): Promise<void> => {
    const params = GetStationParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const rows = await db
      .select({
        id: reviewsTable.id,
        userName: usersTable.name,
        stationId: reviewsTable.stationId,
        rating: reviewsTable.rating,
        review: reviewsTable.review,
        createdAt: reviewsTable.createdAt,
      })
      .from(reviewsTable)
      .innerJoin(usersTable, eq(reviewsTable.userId, usersTable.id))
      .where(eq(reviewsTable.stationId, params.data.stationId))
      .orderBy(desc(reviewsTable.createdAt));
    res.json(ListStationReviewsResponse.parse(rows));
  },
);

router.post(
  "/stations/:stationId/reviews",
  async (req, res): Promise<void> => {
    const user = await requireUser(req, res);
    if (!user) return;
    const params = CreateStationReviewParams.safeParse(req.params);
    const body = CreateStationReviewBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const [station] = await db
      .select({ id: stationsTable.id })
      .from(stationsTable)
      .where(eq(stationsTable.id, params.data.stationId))
      .limit(1);
    if (!station) {
      res.status(404).json({ error: "Station not found." });
      return;
    }
    const [review] = await db
      .insert(reviewsTable)
      .values({
        userId: user.id,
        stationId: station.id,
        rating: body.data.rating,
        review: body.data.review.trim(),
      })
      .returning();
    if (!review) {
      res.status(500).json({ error: "Could not save your review." });
      return;
    }
    await refreshRating(station.id);
    res.status(201).json(
      CreateStationReviewResponse.parse({
        ...review,
        userName: user.name,
      }),
    );
  },
);

router.get("/recommendations", async (req, res): Promise<void> => {
  const parsed = GetRecommendationQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { latitude, longitude } = parsed.data;
  const candidates = await db.select().from(stationsTable);
  const hasLocation = latitude !== undefined && longitude !== undefined;
  const lowestKnownPrice = candidates
    .map((station) => station.pricePerKg)
    .filter((price): price is number => price != null && price > 0)
    .sort((a, b) => a - b)[0];
  const effectiveAvailability = (station: (typeof candidates)[number]) =>
    station.demoData
      ? availabilityFromStock(station.stockKg) ?? (station.availability as Availability)
      : (station.availability as Availability);
  const scoreStation = (station: (typeof candidates)[number]) => {
    const availability = effectiveAvailability(station);
    let score = availability === "AVAILABLE" ? 4 : availability === "LOW" ? 1.5 : -2;
    if (station.stockKg != null) score += Math.min(station.stockKg, 500) / 500;
    if (station.pricePerKg != null && lowestKnownPrice != null) {
      score += Math.max(0, 1 - (station.pricePerKg - lowestKnownPrice) / Math.max(lowestKnownPrice, 1));
    }
    score += Math.min(Math.max(station.discountPercent, 0), 10) / 10;
    if (hasLocation) {
      score -= haversineKm(latitude, longitude, station.latitude, station.longitude) * 0.08;
    } else {
      score += station.rating * 0.1;
    }
    return score;
  };
  candidates.sort((a, b) => {
    return scoreStation(b) - scoreStation(a);
  });
  const station = candidates[0];
  if (!station) {
    res.status(404).json({ error: "No stations are listed yet." });
    return;
  }
  const nearest = await stationView(station, latitude, longitude);
  const reasons = [
    effectiveAvailability(station) === "AVAILABLE"
      ? "marked available"
      : effectiveAvailability(station) === "LOW"
        ? "reported running low"
        : "reported unavailable",
    station.stockKg == null ? "stock not reported" : `${station.stockKg} kg ${station.demoData ? "sample stock" : "reported stock"}`,
    station.pricePerKg == null ? "price not reported" : `₹${station.pricePerKg.toFixed(2)}/kg`,
    station.discountPercent > 0 ? `${station.discountPercent}% supplier-approved discount` : "no station discount",
    hasLocation && nearest.distanceKm != null ? `${nearest.distanceKm} km from your location` : "",
  ].filter(Boolean);
  res.json(
    GetRecommendationResponse.parse({
      station: nearest,
      explanation: `Ranked using reported availability, stock, known price, approved discount${hasLocation ? " and your location" : " and station rating"}. This station is ${reasons.join("; ")}.${station.demoData ? " Sample values are not live station data." : ""}`,
    }),
  );
});

router.get("/availability/events", (req, res): void => {
  res.status(200);
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();
  res.write("retry: 5000\n\n");
  availabilityClients.add(res);
  const heartbeat = setInterval(() => {
    res.write(": keep-alive\n\n");
  }, 25_000);
  req.on("close", () => {
    clearInterval(heartbeat);
    availabilityClients.delete(res);
  });
});

router.get("/supplier/stations", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "supplier");
  if (!user) return;
  const rows = await db
    .select()
    .from(stationsTable)
    .where(eq(stationsTable.supplierId, user.id));
  const views = await Promise.all(rows.map((row) => stationView(row)));
  res.json(ListSupplierStationsResponse.parse(views));
});

router.patch(
  "/supplier/stations/:stationId/availability",
  async (req, res): Promise<void> => {
    const user = await requireRole(req, res, "supplier");
    if (!user) return;
    const params = UpdateSupplierAvailabilityParams.safeParse(req.params);
    const body = UpdateSupplierAvailabilityBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const [assigned] = await db
      .select({ id: stationsTable.id })
      .from(stationsTable)
      .where(
        and(
          eq(stationsTable.id, params.data.stationId),
          eq(stationsTable.supplierId, user.id),
        ),
      )
      .limit(1);
    if (!assigned) {
      res.status(403).json({ error: "This station is not assigned to you." });
      return;
    }
    const updated = await applyAvailability(
      assigned.id,
      user.id,
      body.data,
    );
    if (!updated) {
      res.status(404).json({ error: "Station not found." });
      return;
    }
    res.json(UpdateSupplierAvailabilityResponse.parse(updated));
  },
);

router.get("/admin/summary", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const [stations, userCounts, [reviewCount]] = await Promise.all([
    db.select().from(stationsTable),
    db
      .select({ role: usersTable.role, total: count() })
      .from(usersTable)
      .groupBy(usersTable.role),
    db.select({ value: count() }).from(reviewsTable),
  ]);
  const staleCutoff = Date.now() - STALE_AFTER_MS;
  const summary = {
    totalStations: stations.length,
    availableStations: stations.filter((s) => s.availability === "AVAILABLE").length,
    lowStockStations: stations.filter((s) => s.availability === "LOW").length,
    unavailableStations: stations.filter((s) => s.availability === "NOT_AVAILABLE").length,
    staleStations: stations.filter(
      (s) =>
        !s.availabilityUpdatedAt ||
        s.availabilityUpdatedAt.getTime() < staleCutoff ||
        s.demoData,
    ).length,
    totalUsers: Number(userCounts.find((row) => row.role === "user")?.total ?? 0),
    totalSuppliers: Number(
      userCounts.find((row) => row.role === "supplier")?.total ?? 0,
    ),
    totalReviews: Number(reviewCount?.value ?? 0),
  };
  res.json(GetAdminSummaryResponse.parse(summary));
});

router.get("/admin/activity", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const rows = await db
    .select({
      id: availabilityUpdatesTable.id,
      stationId: availabilityUpdatesTable.stationId,
      stationName: stationsTable.stationName,
      availability: availabilityUpdatesTable.availability,
      stockKg: availabilityUpdatesTable.stockKg,
      pricePerKg: availabilityUpdatesTable.pricePerKg,
      availabilityNote: availabilityUpdatesTable.availabilityNote,
      updatedAt: availabilityUpdatesTable.updatedAt,
      updatedBy: usersTable.name,
    })
    .from(availabilityUpdatesTable)
    .innerJoin(
      stationsTable,
      eq(availabilityUpdatesTable.stationId, stationsTable.id),
    )
    .innerJoin(usersTable, eq(availabilityUpdatesTable.updatedBy, usersTable.id))
    .orderBy(desc(availabilityUpdatesTable.updatedAt))
    .limit(20);
  res.json(ListAdminActivityResponse.parse(rows));
});

router.get("/admin/stations", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const rows = await db.select().from(stationsTable);
  const views = await Promise.all(rows.map((row) => stationView(row)));
  res.json(ListAdminStationsResponse.parse(views));
});

router.post("/admin/stations", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const parsed = CreateStationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (parsed.data.supplierId !== undefined && parsed.data.supplierId !== null) {
    const [supplier] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(
        and(
          eq(usersTable.id, parsed.data.supplierId),
          eq(usersTable.role, "supplier"),
        ),
      )
      .limit(1);
    if (!supplier) {
      res.status(400).json({ error: "Choose a valid supplier account." });
      return;
    }
  }
  const [station] = await db
    .insert(stationsTable)
    .values({
      ...parsed.data,
      supplierId: parsed.data.supplierId ?? null,
      availability: "NOT_AVAILABLE",
      demoData: false,
    })
    .returning();
  if (!station) {
    res.status(500).json({ error: "Could not create the station." });
    return;
  }
  res.status(201).json(
    CreateStationResponse.parse(await stationView(station)),
  );
});

router.patch(
  "/admin/stations/:stationId",
  async (req, res): Promise<void> => {
    const admin = await requireRole(req, res, "admin");
    if (!admin) return;
    const params = UpdateStationParams.safeParse(req.params);
    const body = UpdateStationBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    if (body.data.supplierId !== undefined && body.data.supplierId !== null) {
      const [supplier] = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(
          and(
            eq(usersTable.id, body.data.supplierId),
            eq(usersTable.role, "supplier"),
          ),
        )
        .limit(1);
      if (!supplier) {
        res.status(400).json({ error: "Choose a valid supplier account." });
        return;
      }
    }
    const [station] = await db
      .update(stationsTable)
      .set({ ...body.data, updatedAt: new Date() })
      .where(eq(stationsTable.id, params.data.stationId))
      .returning();
    if (!station) {
      res.status(404).json({ error: "Station not found." });
      return;
    }
    res.json(UpdateStationResponse.parse(await stationView(station)));
  },
);

router.delete(
  "/admin/stations/:stationId",
  async (req, res): Promise<void> => {
    const admin = await requireRole(req, res, "admin");
    if (!admin) return;
    const params = DeleteStationParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [station] = await db
      .delete(stationsTable)
      .where(eq(stationsTable.id, params.data.stationId))
      .returning({ id: stationsTable.id });
    if (!station) {
      res.status(404).json({ error: "Station not found." });
      return;
    }
    res.json(DeleteStationResponse.parse(undefined));
  },
);

router.patch(
  "/admin/stations/:stationId/availability",
  async (req, res): Promise<void> => {
    const admin = await requireRole(req, res, "admin");
    if (!admin) return;
    const params = UpdateAvailabilityParams.safeParse(req.params);
    const body = UpdateAvailabilityBody.safeParse(req.body);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const station = await applyAvailability(
      params.data.stationId,
      admin.id,
      body.data,
    );
    if (!station) {
      res.status(404).json({ error: "Station not found." });
      return;
    }
    res.json(UpdateAvailabilityResponse.parse(station));
  },
);

router.get("/admin/users", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const users = await db
    .select({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
    })
    .from(usersTable)
    .orderBy(usersTable.name);
  res.json(ListUsersResponse.parse(users));
});

router.post("/admin/users", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const parsed = CreateManagedUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const email = parsed.data.email.trim().toLowerCase();
  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, email))
    .limit(1);
  if (existing) {
    res.status(409).json({ error: "An account already uses that email." });
    return;
  }
  const [user] = await db
    .insert(usersTable)
    .values({
      name: parsed.data.name.trim(),
      email,
      passwordHash: hashPassword(parsed.data.password),
      role: parsed.data.role,
    })
    .returning({
      id: usersTable.id,
      name: usersTable.name,
      email: usersTable.email,
      role: usersTable.role,
    });
  if (!user) {
    res.status(500).json({ error: "Could not create the account." });
    return;
  }
  res.status(201).json(CreateManagedUserResponse.parse(user));
});

router.get("/admin/reviews", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const rows = await db
    .select({
      id: reviewsTable.id,
      userName: usersTable.name,
      stationId: reviewsTable.stationId,
      rating: reviewsTable.rating,
      review: reviewsTable.review,
      createdAt: reviewsTable.createdAt,
    })
    .from(reviewsTable)
    .innerJoin(usersTable, eq(reviewsTable.userId, usersTable.id))
    .orderBy(desc(reviewsTable.createdAt));
  res.json(ListAdminReviewsResponse.parse(rows));
});

router.delete(
  "/admin/reviews/:reviewId",
  async (req, res): Promise<void> => {
    const admin = await requireRole(req, res, "admin");
    if (!admin) return;
    const params = DeleteReviewParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const [review] = await db
      .delete(reviewsTable)
      .where(eq(reviewsTable.id, params.data.reviewId))
      .returning({ id: reviewsTable.id, stationId: reviewsTable.stationId });
    if (!review) {
      res.status(404).json({ error: "Review not found." });
      return;
    }
    await refreshRating(review.stationId);
    res.json(DeleteReviewResponse.parse(undefined));
  },
);

const VEHICLE_CATEGORIES = [
  "Motorcycle/Scooter",
  "Auto Rickshaw",
  "Car/Hatchback",
  "Sedan",
  "SUV/MUV",
  "Taxi/Cab",
  "Jeep",
  "Pickup Truck",
  "Light Commercial Vehicle",
  "Bus",
  "Truck/Heavy Commercial Vehicle",
  "Other",
] as const;
const VEHICLE_FUELS = ["CNG", "Petrol + CNG", "Petrol", "Diesel", "Electric", "Other"] as const;
const CNG_FITMENTS = ["factory_fitted", "retrofitted", "not_confirmed", "not_cng"] as const;
const vehicleFields = {
  registrationNumber: z.string().trim().regex(
    /^[A-Za-z0-9 -]{3,20}$/,
    "Use 3–20 letters, numbers, spaces or hyphens for the registration number.",
  ),
  make: z.string().trim().min(1).max(80),
  model: z.string().trim().min(1).max(80),
  category: z.enum(VEHICLE_CATEGORIES),
  fuelType: z.enum(VEHICLE_FUELS),
  cngFitment: z.enum(CNG_FITMENTS),
  nickname: z.string().trim().max(60).nullable().optional(),
  isDefault: z.boolean().optional(),
};
const vehicleCreateBody = z.object(vehicleFields);
const vehicleUpdateBody = z.object(vehicleFields).partial().refine(
  (value) => Object.keys(value).length > 0,
  "Provide at least one vehicle field to update.",
);
const positiveIdParam = z.object({ id: z.coerce.number().int().positive() });
const fuelRequestBody = z.object({
  stationId: z.number().int().positive(),
  vehicleId: z.number().int().positive(),
  quantityKg: z.number().finite().positive().max(500),
  requestKey: z.string().uuid(),
});
const confirmFuelBody = z.object({}).strict();
const discountBody = z.object({
  discountPercent: z.number().finite().refine(
    (value) => value === 0 || (value >= 5 && value <= 10),
    "Discount must be 0% or between 5% and 10%.",
  ),
});

function receiptCode(transactionId: number): string {
  return `CNG-${new Date().getFullYear()}-${String(transactionId).padStart(6, "0")}`;
}

function transactionView(row: {
  id: number;
  stationId: number;
  stationName: string;
  vehicleId: number;
  registrationNumber: string;
  nickname: string | null;
  actualKg: number | null;
  unitPrice: number | null;
  discountPercent: number;
  totalAmount: number | null;
  status: string;
  paymentStatus: string;
  paymentReference: string | null;
  stockDeducted: boolean;
  createdAt: Date;
  confirmedAt: Date | null;
  paymentVerifiedAt: Date | null;
  userName?: string;
}) {
  return {
    ...row,
    receiptCode: receiptCode(row.id),
    receiptUrl: `/api/driver/fuel-transactions/${row.id}/receipt`,
  };
}

router.get("/driver/vehicles", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const vehicles = await db
    .select()
    .from(vehiclesTable)
    .where(eq(vehiclesTable.userId, user.id))
    .orderBy(desc(vehiclesTable.isDefault), vehiclesTable.createdAt);
  res.json(vehicles);
});

router.post("/driver/vehicles", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const parsed = vehicleCreateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const registrationNumber = parsed.data.registrationNumber.toUpperCase();
  const result = await db.transaction(async (tx) => {
    const [duplicate] = await tx
      .select({ id: vehiclesTable.id })
      .from(vehiclesTable)
      .where(ilike(vehiclesTable.registrationNumber, registrationNumber))
      .limit(1);
    if (duplicate) return { error: "A vehicle with that registration already exists." };
    const [existing] = await tx
      .select({ id: vehiclesTable.id })
      .from(vehiclesTable)
      .where(eq(vehiclesTable.userId, user.id))
      .limit(1);
    if (parsed.data.isDefault || !existing) {
      await tx
        .update(vehiclesTable)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(eq(vehiclesTable.userId, user.id));
    }
    const [vehicle] = await tx
      .insert(vehiclesTable)
      .values({
        userId: user.id,
        ...parsed.data,
        registrationNumber,
        nickname: parsed.data.nickname?.trim() || null,
        isDefault: parsed.data.isDefault ?? !existing,
      })
      .returning();
    return vehicle ? { vehicle } : { error: "Could not save this vehicle." };
  });
  if ("error" in result) {
    res.status(409).json({ error: result.error });
    return;
  }
  res.status(201).json(result.vehicle);
});

router.patch("/driver/vehicles/:id", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const params = positiveIdParam.safeParse(req.params);
  const parsed = vehicleUpdateBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: !params.success ? params.error.message : parsed.error?.message ?? "Invalid request." });
    return;
  }
  const changes = {
    ...parsed.data,
    ...(parsed.data.registrationNumber
      ? { registrationNumber: parsed.data.registrationNumber.toUpperCase() }
      : {}),
    ...(parsed.data.nickname !== undefined
      ? { nickname: parsed.data.nickname?.trim() || null }
      : {}),
    updatedAt: new Date(),
  };
  const result = await db.transaction(async (tx) => {
    const [vehicle] = await tx
      .select()
      .from(vehiclesTable)
      .where(and(eq(vehiclesTable.id, params.data.id), eq(vehiclesTable.userId, user.id)))
      .for("update")
      .limit(1);
    if (!vehicle) return { error: "Vehicle not found.", status: 404 };
    if (
      changes.registrationNumber &&
      changes.registrationNumber.toLowerCase() !== vehicle.registrationNumber.toLowerCase()
    ) {
      const [duplicate] = await tx
        .select({ id: vehiclesTable.id })
        .from(vehiclesTable)
        .where(ilike(vehiclesTable.registrationNumber, changes.registrationNumber))
        .limit(1);
      if (duplicate) return { error: "A vehicle with that registration already exists.", status: 409 };
    }
    if (parsed.data.isDefault === true) {
      await tx
        .update(vehiclesTable)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(eq(vehiclesTable.userId, user.id));
    }
    const [updated] = await tx
      .update(vehiclesTable)
      .set(changes)
      .where(and(eq(vehiclesTable.id, vehicle.id), eq(vehiclesTable.userId, user.id)))
      .returning();
    return updated ? { vehicle: updated } : { error: "Could not update this vehicle.", status: 500 };
  });
  if ("error" in result) {
    res.status(result.status ?? 500).json({ error: result.error });
    return;
  }
  res.json(result.vehicle);
});

router.get("/driver/fuel-options", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const rows = await db.select().from(stationsTable).orderBy(stationsTable.stationName);
  res.json(
    rows.map((station) => ({
      id: station.id,
      stationName: station.stationName,
      address: station.address,
      latitude: station.latitude,
      longitude: station.longitude,
      pricePerKg: station.pricePerKg,
      stockKg: station.stockKg,
      discountPercent: station.discountPercent,
      availability: station.demoData
        ? availabilityFromStock(station.stockKg) ?? station.availability
        : station.availability,
      availabilityUpdatedAt: station.availabilityUpdatedAt,
      demoData: station.demoData,
    })),
  );
});

router.post("/driver/fuel-transactions", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const parsed = fuelRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { stationId, vehicleId, quantityKg, requestKey } = parsed.data;
  const [existingRequest] = await db
    .select()
    .from(fuelTransactionsTable)
    .where(and(
      eq(fuelTransactionsTable.userId, user.id),
      eq(fuelTransactionsTable.idempotencyKey, requestKey),
    ))
    .limit(1);
  if (existingRequest) {
    if (existingRequest.stationId !== stationId || existingRequest.vehicleId !== vehicleId) {
      res.status(409).json({ error: "That request key is already assigned to a different refuel." });
      return;
    }
    res.json(existingRequest);
    return;
  }
  const [[vehicle], [station]] = await Promise.all([
    db.select().from(vehiclesTable).where(and(
      eq(vehiclesTable.id, vehicleId),
      eq(vehiclesTable.userId, user.id),
    )).limit(1),
    db.select().from(stationsTable).where(eq(stationsTable.id, stationId)).limit(1),
  ]);
  if (!vehicle) {
    res.status(404).json({ error: "Choose one of your saved vehicles." });
    return;
  }
  if (!["factory_fitted", "retrofitted"].includes(vehicle.cngFitment)) {
    res.status(400).json({ error: "This vehicle is not marked as CNG-fitted. Confirm its fitment before requesting a refuel." });
    return;
  }
  if (!station) {
    res.status(404).json({ error: "Station not found." });
    return;
  }
  if (!station.supplierId) {
    res.status(400).json({ error: "This station does not have an assigned supplier to confirm refuels." });
    return;
  }
  if (station.pricePerKg == null || station.pricePerKg <= 0) {
    res.status(400).json({ error: "The station has not reported a current price per kg." });
    return;
  }
  if (station.stockKg == null || station.stockKg <= 0) {
    res.status(400).json({ error: "The station has no current stock report; refuel requests are unavailable." });
    return;
  }
  if (quantityKg > station.stockKg) {
    res.status(400).json({ error: "Requested quantity is greater than the station's reported stock." });
    return;
  }
  const [created] = await db
    .insert(fuelTransactionsTable)
    .values({ userId: user.id, stationId, vehicleId, actualKg: quantityKg, idempotencyKey: requestKey })
    .onConflictDoNothing({
      target: [fuelTransactionsTable.userId, fuelTransactionsTable.idempotencyKey],
    })
    .returning();
  if (created) {
    res.status(201).json(created);
    return;
  }
  const [retryResult] = await db
    .select()
    .from(fuelTransactionsTable)
    .where(and(
      eq(fuelTransactionsTable.userId, user.id),
      eq(fuelTransactionsTable.idempotencyKey, requestKey),
    ))
    .limit(1);
  if (retryResult) {
    if (retryResult.stationId !== stationId || retryResult.vehicleId !== vehicleId) {
      res.status(409).json({ error: "That request key is already assigned to a different refuel." });
      return;
    }
    res.json(retryResult);
    return;
  }
  res.status(500).json({ error: "Could not record the refuel request." });
});

router.get("/driver/fuel-transactions", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const rows = await db
    .select({
      id: fuelTransactionsTable.id,
      stationId: fuelTransactionsTable.stationId,
      stationName: stationsTable.stationName,
      vehicleId: fuelTransactionsTable.vehicleId,
      registrationNumber: vehiclesTable.registrationNumber,
      nickname: vehiclesTable.nickname,
      actualKg: fuelTransactionsTable.actualKg,
      unitPrice: fuelTransactionsTable.unitPrice,
      discountPercent: fuelTransactionsTable.discountPercent,
      totalAmount: fuelTransactionsTable.totalAmount,
      status: fuelTransactionsTable.status,
      paymentStatus: fuelTransactionsTable.paymentStatus,
      paymentReference: fuelTransactionsTable.paymentReference,
      stockDeducted: fuelTransactionsTable.stockDeducted,
      createdAt: fuelTransactionsTable.createdAt,
      confirmedAt: fuelTransactionsTable.confirmedAt,
      paymentVerifiedAt: fuelTransactionsTable.paymentVerifiedAt,
    })
    .from(fuelTransactionsTable)
    .innerJoin(stationsTable, eq(fuelTransactionsTable.stationId, stationsTable.id))
    .innerJoin(vehiclesTable, eq(fuelTransactionsTable.vehicleId, vehiclesTable.id))
    .where(eq(fuelTransactionsTable.userId, user.id))
    .orderBy(desc(fuelTransactionsTable.createdAt))
    .limit(100);
  res.json(rows.map(transactionView));
});

router.get("/driver/fuel-transactions/:id/receipt", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  const params = positiveIdParam.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select({
      id: fuelTransactionsTable.id,
      stationId: fuelTransactionsTable.stationId,
      stationName: stationsTable.stationName,
      vehicleId: fuelTransactionsTable.vehicleId,
      registrationNumber: vehiclesTable.registrationNumber,
      nickname: vehiclesTable.nickname,
      actualKg: fuelTransactionsTable.actualKg,
      unitPrice: fuelTransactionsTable.unitPrice,
      discountPercent: fuelTransactionsTable.discountPercent,
      totalAmount: fuelTransactionsTable.totalAmount,
      status: fuelTransactionsTable.status,
      paymentStatus: fuelTransactionsTable.paymentStatus,
      paymentReference: fuelTransactionsTable.paymentReference,
      stockDeducted: fuelTransactionsTable.stockDeducted,
      createdAt: fuelTransactionsTable.createdAt,
      confirmedAt: fuelTransactionsTable.confirmedAt,
      paymentVerifiedAt: fuelTransactionsTable.paymentVerifiedAt,
    })
    .from(fuelTransactionsTable)
    .innerJoin(stationsTable, eq(fuelTransactionsTable.stationId, stationsTable.id))
    .innerJoin(vehiclesTable, eq(fuelTransactionsTable.vehicleId, vehiclesTable.id))
    .where(and(
      eq(fuelTransactionsTable.id, params.data.id),
      eq(fuelTransactionsTable.userId, user.id),
    ))
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Receipt not found." });
    return;
  }
  res.json(transactionView(row));
});

router.get("/supplier/fuel-transactions", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "supplier");
  if (!user) return;
  const rows = await db
    .select({
      id: fuelTransactionsTable.id,
      stationId: fuelTransactionsTable.stationId,
      stationName: stationsTable.stationName,
      vehicleId: fuelTransactionsTable.vehicleId,
      registrationNumber: vehiclesTable.registrationNumber,
      nickname: vehiclesTable.nickname,
      actualKg: fuelTransactionsTable.actualKg,
      unitPrice: fuelTransactionsTable.unitPrice,
      discountPercent: fuelTransactionsTable.discountPercent,
      totalAmount: fuelTransactionsTable.totalAmount,
      status: fuelTransactionsTable.status,
      paymentStatus: fuelTransactionsTable.paymentStatus,
      paymentReference: fuelTransactionsTable.paymentReference,
      stockDeducted: fuelTransactionsTable.stockDeducted,
      createdAt: fuelTransactionsTable.createdAt,
      confirmedAt: fuelTransactionsTable.confirmedAt,
      paymentVerifiedAt: fuelTransactionsTable.paymentVerifiedAt,
      userName: usersTable.name,
    })
    .from(fuelTransactionsTable)
    .innerJoin(stationsTable, eq(fuelTransactionsTable.stationId, stationsTable.id))
    .innerJoin(vehiclesTable, eq(fuelTransactionsTable.vehicleId, vehiclesTable.id))
    .innerJoin(usersTable, eq(fuelTransactionsTable.userId, usersTable.id))
    .where(eq(stationsTable.supplierId, user.id))
    .orderBy(desc(fuelTransactionsTable.createdAt))
    .limit(100);
  res.json(rows.map(transactionView));
});

router.get("/supplier/station-discounts", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "supplier");
  if (!user) return;
  const rows = await db
    .select({
      id: stationsTable.id,
      stationName: stationsTable.stationName,
      pricePerKg: stationsTable.pricePerKg,
      stockKg: stationsTable.stockKg,
      discountPercent: stationsTable.discountPercent,
    })
    .from(stationsTable)
    .where(eq(stationsTable.supplierId, user.id))
    .orderBy(stationsTable.stationName);
  res.json(rows);
});

router.patch("/supplier/stations/:stationId/discount", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "supplier");
  if (!user) return;
  const params = positiveIdParam.safeParse({ id: req.params.stationId });
  const parsed = discountBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: !params.success ? params.error.message : parsed.error?.message ?? "Invalid request." });
    return;
  }
  const [station] = await db
    .update(stationsTable)
    .set({ discountPercent: parsed.data.discountPercent, updatedAt: new Date() })
    .where(and(
      eq(stationsTable.id, params.data.id),
      eq(stationsTable.supplierId, user.id),
    ))
    .returning({
      id: stationsTable.id,
      discountPercent: stationsTable.discountPercent,
    });
  if (!station) {
    res.status(404).json({ error: "Station not found in your supplier account." });
    return;
  }
  res.json(station);
});

router.patch("/supplier/fuel-transactions/:id/confirm", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "supplier");
  if (!user) return;
  const params = positiveIdParam.safeParse(req.params);
  const parsed = confirmFuelBody.safeParse(req.body ?? {});
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: !params.success ? params.error.message : parsed.error?.message ?? "Invalid request." });
    return;
  }
  const now = new Date();
  const result = await db.transaction(async (tx) => {
    const [record] = await tx
      .select()
      .from(fuelTransactionsTable)
      .where(eq(fuelTransactionsTable.id, params.data.id))
      .for("update")
      .limit(1);
    if (!record) return { error: "Refuel request not found.", status: 404 as const };
    if (record.status !== "awaiting_confirmation" || record.stockDeducted) {
      return { error: "This refuel has already been confirmed or is no longer pending.", status: 409 as const };
    }
    const [station] = await tx
      .select()
      .from(stationsTable)
      .where(eq(stationsTable.id, record.stationId))
      .for("update")
      .limit(1);
    if (!station || station.supplierId !== user.id) {
      return { error: "This station is not assigned to your supplier account.", status: 403 as const };
    }
    if (station.pricePerKg == null || station.pricePerKg <= 0) {
      return { error: "Set a current station price before confirming a refuel.", status: 400 as const };
    }
    const requestedKg = record.actualKg;
    if (requestedKg == null || requestedKg <= 0) {
      return { error: "This request has no valid driver-requested quantity.", status: 400 as const };
    }
    if (station.stockKg == null || requestedKg > station.stockKg) {
      return { error: "The requested quantity exceeds the station's reported stock.", status: 409 as const };
    }
    if (station.discountPercent !== 0 && (station.discountPercent < 5 || station.discountPercent > 10)) {
      return { error: "The station discount must be 0% or between 5% and 10%.", status: 400 as const };
    }
    const remainingStock = Math.max(0, Math.round((station.stockKg - requestedKg) * 100) / 100);
    const [updatedStation] = await tx
      .update(stationsTable)
      .set({
        stockKg: remainingStock,
        availability: availabilityFromStock(remainingStock) ?? station.availability,
        availabilityUpdatedAt: now,
        availabilityUpdatedById: user.id,
        updatedAt: now,
      })
      .where(and(
        eq(stationsTable.id, station.id),
        gte(stationsTable.stockKg, requestedKg),
      ))
      .returning();
    if (!updatedStation) {
      return { error: "Station stock changed. Refresh and confirm the recorded amount again.", status: 409 as const };
    }
    const subtotal = requestedKg * station.pricePerKg;
    const totalAmount = Math.round(
      subtotal * (1 - station.discountPercent / 100) * 100,
    ) / 100;
    const [updatedRecord] = await tx
      .update(fuelTransactionsTable)
      .set({
        actualKg: requestedKg,
        unitPrice: station.pricePerKg,
        discountPercent: station.discountPercent,
        totalAmount,
        status: "confirmed",
        stockDeducted: true,
        confirmedById: user.id,
        confirmedAt: now,
        updatedAt: now,
      })
      .where(and(
        eq(fuelTransactionsTable.id, record.id),
        eq(fuelTransactionsTable.status, "awaiting_confirmation"),
        eq(fuelTransactionsTable.stockDeducted, false),
      ))
      .returning();
    if (!updatedRecord) {
      throw new Error("Fuel confirmation lost its locked transaction row; rolling back the stock update.");
    }
    await tx.insert(availabilityUpdatesTable).values({
      stationId: station.id,
      availability: updatedStation.availability,
      stockKg: remainingStock,
      pricePerKg: station.pricePerKg,
      availabilityNote: station.availabilityNote,
      updatedBy: user.id,
      updatedAt: now,
    });
    return { transaction: updatedRecord, station: updatedStation };
  });
  if ("error" in result) {
    res.status(result.status ?? 500).json({ error: result.error });
    return;
  }
  broadcastAvailability(await stationView(result.station));
  res.json(result.transaction);
});

router.post("/driver/fuel-transactions/:id/pay-test", async (req, res): Promise<void> => {
  const user = await requireRole(req, res, "user");
  if (!user) return;
  if (process.env.NODE_ENV === "production" || process.env.CNGCONNECT_PAYMENT_MODE !== "test") {
    res.status(503).json({ error: "The local test payment simulator is disabled. Configure a real payment provider before accepting payments." });
    return;
  }
  const params = positiveIdParam.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const result = await db.transaction(async (tx) => {
    const [record] = await tx
      .select()
      .from(fuelTransactionsTable)
      .where(and(
        eq(fuelTransactionsTable.id, params.data.id),
        eq(fuelTransactionsTable.userId, user.id),
      ))
      .for("update")
      .limit(1);
    if (!record) return { error: "Refuel receipt not found.", status: 404 as const };
    if (record.paymentStatus === "test_paid") return { transaction: record, idempotent: true };
    if (record.status !== "confirmed" || !record.stockDeducted || record.totalAmount == null) {
      return { error: "Only supplier-confirmed refuels can be paid.", status: 409 as const };
    }
    const paymentReference = `TEST-${randomBytes(8).toString("hex")}`;
    const payload = `${record.id}:${record.totalAmount.toFixed(2)}:INR:${paymentReference}`;
    const signature = createHmac(
      "sha256",
      process.env.CNGCONNECT_TEST_PAYMENT_SECRET || TEST_PAYMENT_SECRET,
    ).update(payload).digest();
    const expected = createHmac(
      "sha256",
      process.env.CNGCONNECT_TEST_PAYMENT_SECRET || TEST_PAYMENT_SECRET,
    ).update(payload).digest();
    if (signature.length !== expected.length || !timingSafeEqual(signature, expected)) {
      return { error: "The test provider capture could not be verified.", status: 502 as const };
    }
    const [paid] = await tx
      .update(fuelTransactionsTable)
      .set({
        status: "paid_test",
        paymentStatus: "test_paid",
        paymentReference,
        paymentVerifiedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(and(
        eq(fuelTransactionsTable.id, record.id),
        eq(fuelTransactionsTable.paymentStatus, "not_started"),
      ))
      .returning();
    return paid
      ? { transaction: paid, idempotent: false }
      : { error: "Payment was already recorded; refresh the receipt.", status: 409 as const };
  });
  if ("error" in result) {
    res.status(result.status ?? 500).json({ error: result.error });
    return;
  }
  res.json({ ...result.transaction, receiptCode: receiptCode(result.transaction.id), mode: "test", idempotent: result.idempotent });
});

router.get("/admin/fuel-transactions", async (req, res): Promise<void> => {
  const admin = await requireRole(req, res, "admin");
  if (!admin) return;
  const rows = await db
    .select({
      id: fuelTransactionsTable.id,
      stationId: fuelTransactionsTable.stationId,
      stationName: stationsTable.stationName,
      vehicleId: fuelTransactionsTable.vehicleId,
      registrationNumber: vehiclesTable.registrationNumber,
      nickname: vehiclesTable.nickname,
      actualKg: fuelTransactionsTable.actualKg,
      unitPrice: fuelTransactionsTable.unitPrice,
      discountPercent: fuelTransactionsTable.discountPercent,
      totalAmount: fuelTransactionsTable.totalAmount,
      status: fuelTransactionsTable.status,
      paymentStatus: fuelTransactionsTable.paymentStatus,
      paymentReference: fuelTransactionsTable.paymentReference,
      stockDeducted: fuelTransactionsTable.stockDeducted,
      createdAt: fuelTransactionsTable.createdAt,
      confirmedAt: fuelTransactionsTable.confirmedAt,
      paymentVerifiedAt: fuelTransactionsTable.paymentVerifiedAt,
      userName: usersTable.name,
    })
    .from(fuelTransactionsTable)
    .innerJoin(stationsTable, eq(fuelTransactionsTable.stationId, stationsTable.id))
    .innerJoin(vehiclesTable, eq(fuelTransactionsTable.vehicleId, vehiclesTable.id))
    .innerJoin(usersTable, eq(fuelTransactionsTable.userId, usersTable.id))
    .orderBy(desc(fuelTransactionsTable.createdAt))
    .limit(100);
  res.json(rows.map(transactionView));
});

export default router;