import { Router, type IRouter } from "express";
import healthRouter from "./health";
import cngconnectRouter from "./cngconnect";

const router: IRouter = Router();

router.use(healthRouter);
router.use(cngconnectRouter);

export default router;
