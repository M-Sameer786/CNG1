import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ArrowRight, Check, Clock3, Fuel, LoaderCircle, Printer, ShieldCheck, Truck, Wallet } from "lucide-react";
import { Link } from "wouter";
import "./mobility.css";

type Vehicle = {
  id: number;
  registrationNumber: string;
  make: string;
  model: string;
  category: string;
  fuelType: string;
  cngFitment: string;
  nickname: string | null;
  isDefault: boolean;
};

type FuelStation = {
  id: number;
  stationName: string;
  address: string;
  pricePerKg: number | null;
  stockKg: number | null;
  discountPercent: number;
  availability: string;
  availabilityUpdatedAt: string | null;
  demoData: boolean;
};

type FuelTransaction = {
  id: number;
  stationId: number;
  stationName: string;
  vehicleId: number;
  registrationNumber: string;
  nickname: string | null;
  actualKg: number | null;
  unitPrice: number | null;
  discountPercent: number;
  totalAmount: number | null;
  status: string;
  paymentStatus: string;
  paymentReference: string | null;
  stockDeducted: boolean;
  createdAt: string;
  confirmedAt: string | null;
  paymentVerifiedAt: string | null;
  receiptCode?: string;
  userName?: string;
};

type SupplierStation = {
  id: number;
  stationName: string;
  pricePerKg: number | null;
  stockKg: number | null;
  discountPercent: number;
};

type VehicleDraft = Omit<Vehicle, "id" | "userId">;
const emptyVehicle: VehicleDraft = {
  registrationNumber: "",
  make: "",
  model: "",
  category: "Car/Hatchback",
  fuelType: "Petrol + CNG",
  cngFitment: "not_confirmed",
  nickname: "",
  isDefault: false,
};

const categories = [
  "Motorcycle/Scooter", "Auto Rickshaw", "Car/Hatchback", "Sedan", "SUV/MUV",
  "Taxi/Cab", "Jeep", "Pickup Truck", "Light Commercial Vehicle", "Bus",
  "Truck/Heavy Commercial Vehicle", "Other",
];
const fitmentLabels: Record<string, string> = {
  factory_fitted: "Factory-fitted CNG (driver reported)",
  retrofitted: "Retrofitted CNG (driver reported)",
  not_confirmed: "CNG fitment not confirmed",
  not_cng: "Not marked CNG-compatible",
};
const money = (value: number | null | undefined) =>
  value == null ? "Not reported" : `₹${value.toFixed(2)}`;
const dateTime = (value?: string | null) =>
  value ? new Date(value).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "Not recorded";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    credentials: "include",
    ...init,
    headers: {
      ...(init?.body ? { "Content-Type": "application/json" } : {}),
      ...init?.headers,
    },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status}).`);
  return body as T;
}

function ErrorMessage({ children }: { children: string }) {
  return <div className="mobility-error" role="alert">{children}</div>;
}

export function VehiclePage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [draft, setDraft] = useState<VehicleDraft>(emptyVehicle);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function reload() {
    setLoading(true);
    try {
      setVehicles(await api<Vehicle[]>("/api/driver/vehicles"));
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not load your vehicles.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void reload(); }, []);

  function edit(vehicle: Vehicle) {
    setEditingId(vehicle.id);
    setDraft({
      registrationNumber: vehicle.registrationNumber,
      make: vehicle.make,
      model: vehicle.model,
      category: vehicle.category,
      fuelType: vehicle.fuelType,
      cngFitment: vehicle.cngFitment,
      nickname: vehicle.nickname ?? "",
      isDefault: vehicle.isDefault,
    });
    setNotice("");
  }

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const payload = { ...draft, registrationNumber: draft.registrationNumber.trim().toUpperCase() };
      if (editingId) {
        await api<Vehicle>(`/api/driver/vehicles/${editingId}`, {
          method: "PATCH", body: JSON.stringify(payload),
        });
        setNotice("Vehicle details updated.");
      } else {
        await api<Vehicle>("/api/driver/vehicles", {
          method: "POST", body: JSON.stringify(payload),
        });
        setNotice("Vehicle saved to your account.");
      }
      setEditingId(null);
      setDraft(emptyVehicle);
      await reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not save this vehicle.");
    } finally {
      setBusy(false);
    }
  }

  async function setDefault(vehicle: Vehicle) {
    setError("");
    try {
      await api<Vehicle>(`/api/driver/vehicles/${vehicle.id}`, {
        method: "PATCH", body: JSON.stringify({ isDefault: true }),
      });
      await reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not change the default vehicle.");
    }
  }

  return <div className="mobility-page">
    <div className="mobility-heading">
      <div><span className="mobility-eyebrow">DRIVER PROFILE</span><h1>Your vehicles</h1><p>Save more than one vehicle and choose which one you are taking to refuel.</p></div>
      <span className="mobility-heading-icon"><Truck size={22}/></span>
    </div>
    {error && <ErrorMessage>{error}</ErrorMessage>}
    {notice && <div className="mobility-success"><Check size={16}/>{notice}</div>}
    <div className="vehicle-layout">
      <section className="mobility-card vehicle-list">
        <div className="mobility-card-heading"><div><span className="mobility-eyebrow">GARAGE</span><h2>Saved vehicles</h2></div><span className="mobility-count">{vehicles.length}</span></div>
        {loading ? <p className="mobility-muted">Loading vehicles…</p> : vehicles.length ? <div className="vehicle-cards">
          {vehicles.map(vehicle => <article className="vehicle-card" key={vehicle.id}>
            <div className="vehicle-card-top"><div className="vehicle-avatar"><Fuel size={18}/></div><div><b>{vehicle.nickname || vehicle.registrationNumber}</b><small>{vehicle.make} {vehicle.model} · {vehicle.category}</small></div>{vehicle.isDefault && <span className="default-chip">DEFAULT</span>}</div>
            <div className="vehicle-tags"><span>{vehicle.registrationNumber}</span><span>{vehicle.fuelType}</span></div>
            <p className={`fitment-label ${vehicle.cngFitment === "not_confirmed" || vehicle.cngFitment === "not_cng" ? "fitment-warning" : ""}`}>{fitmentLabels[vehicle.cngFitment] || fitmentLabels.not_confirmed}</p>
            <div className="vehicle-actions"><button type="button" onClick={() => edit(vehicle)}>Edit details</button>{!vehicle.isDefault && <button type="button" onClick={() => void setDefault(vehicle)}>Make default</button>}</div>
          </article>)}
        </div> : <div className="mobility-empty"><Truck size={22}/><b>No vehicles saved yet</b><span>Add one to select it before requesting a refuel.</span></div>}
      </section>
      <section className="mobility-card">
        <div className="mobility-card-heading"><div><span className="mobility-eyebrow">{editingId ? "UPDATE DETAILS" : "ADD A VEHICLE"}</span><h2>{editingId ? "Edit vehicle" : "Vehicle details"}</h2></div></div>
        <form className="mobility-form" onSubmit={save}>
          <label>Registration number<input required minLength={3} maxLength={20} value={draft.registrationNumber} onChange={event => setDraft({ ...draft, registrationNumber: event.target.value })} placeholder="KA 22 AB 1234" autoComplete="off"/></label>
          <div className="mobility-form-row">
            <label>Make<input required maxLength={80} value={draft.make} onChange={event => setDraft({ ...draft, make: event.target.value })} placeholder="Manufacturer"/></label>
            <label>Model<input required maxLength={80} value={draft.model} onChange={event => setDraft({ ...draft, model: event.target.value })} placeholder="Model"/></label>
          </div>
          <label>Vehicle type<select value={draft.category} onChange={event => setDraft({ ...draft, category: event.target.value })}>{categories.map(item => <option key={item}>{item}</option>)}</select></label>
          <label>Fuel type<select value={draft.fuelType} onChange={event => setDraft({ ...draft, fuelType: event.target.value })}>{["CNG", "Petrol + CNG", "Petrol", "Diesel", "Electric", "Other"].map(item => <option key={item}>{item}</option>)}</select></label>
          <label>CNG fitment status<select value={draft.cngFitment} onChange={event => setDraft({ ...draft, cngFitment: event.target.value })}>
            <option value="not_confirmed">Not confirmed</option><option value="factory_fitted">Factory-fitted CNG</option><option value="retrofitted">Retrofitted CNG</option><option value="not_cng">Not CNG-compatible</option>
          </select><small className="mobility-help">This is driver-reported, not verified by CNGConnect. Vehicle type alone never implies CNG compatibility.</small></label>
          <label>Nickname <span className="optional-label">optional</span><input maxLength={60} value={draft.nickname ?? ""} onChange={event => setDraft({ ...draft, nickname: event.target.value })} placeholder="e.g. Family car"/></label>
          <label className="mobility-checkbox"><input type="checkbox" checked={draft.isDefault} onChange={event => setDraft({ ...draft, isDefault: event.target.checked })}/> Use as my default vehicle</label>
          <div className="mobility-form-actions"><button type="button" className="mobility-button secondary" onClick={() => { setEditingId(null); setDraft(emptyVehicle); setNotice(""); }}>Clear</button><button className="mobility-button" disabled={busy}>{busy ? "Saving…" : editingId ? "Save changes" : "Save vehicle"} <ArrowRight size={15}/></button></div>
        </form>
      </section>
    </div>
  </div>;
}

export function FuelHistoryPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [stations, setStations] = useState<FuelStation[]>([]);
  const [transactions, setTransactions] = useState<FuelTransaction[]>([]);
  const [vehicleId, setVehicleId] = useState("");
  const [stationId, setStationId] = useState(() => new URLSearchParams(window.location.search).get("station") ?? "");
  const [requestedKg, setRequestedKg] = useState("5");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function reload() {
    setLoading(true);
    try {
      const [vehicleRows, stationRows, transactionRows] = await Promise.all([
        api<Vehicle[]>("/api/driver/vehicles"),
        api<FuelStation[]>("/api/driver/fuel-options"),
        api<FuelTransaction[]>("/api/driver/fuel-transactions"),
      ]);
      setVehicles(vehicleRows);
      setStations(stationRows);
      setTransactions(transactionRows);
      setVehicleId(current => current || String(vehicleRows.find(row => row.isDefault)?.id ?? vehicleRows[0]?.id ?? ""));
      setStationId(current => current || String(stationRows.find(row => row.pricePerKg != null && row.stockKg != null && row.stockKg > 0)?.id ?? ""));
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not load refuel details.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void reload(); }, []);

  const selectedStation = useMemo(() => stations.find(item => String(item.id) === stationId), [stations, stationId]);
  const eligibleVehicles = vehicles.filter(vehicle => ["factory_fitted", "retrofitted"].includes(vehicle.cngFitment));

  async function requestRefuel(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!vehicleId || !stationId) return;
    setBusy(true); setError(""); setNotice("");
    try {
      const quantityKg = Number(requestedKg);
      if (!Number.isFinite(quantityKg) || quantityKg <= 0 || quantityKg > 500) {
        setError("Enter a quantity greater than 0 kg and no more than 500 kg.");
        return;
      }
      if (selectedStation?.stockKg != null && quantityKg > selectedStation.stockKg) {
        setError("Requested quantity is greater than the station's reported stock.");
        return;
      }
      await api<FuelTransaction>("/api/driver/fuel-transactions", {
        method: "POST",
        body: JSON.stringify({ stationId: Number(stationId), vehicleId: Number(vehicleId), quantityKg, requestKey: window.crypto.randomUUID() }),
      });
      setNotice(`Request for ${quantityKg.toFixed(2)} kg recorded. The supplier will confirm after dispensing.`);
      await reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not record the refuel request.");
    } finally {
      setBusy(false);
    }
  }

  async function payTest(transactionId: number) {
    setBusy(true); setError(""); setNotice("");
    try {
      await api(`/api/driver/fuel-transactions/${transactionId}/pay-test`, { method: "POST" });
      setNotice("Test payment verified by the local simulator. No real money was charged.");
      await reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Test payment could not be completed.");
    } finally {
      setBusy(false);
    }
  }

  return <div className="mobility-page">
    <div className="mobility-heading">
      <div><span className="mobility-eyebrow">REFUELS & RECEIPTS</span><h1>Fuel activity</h1><p>Select your vehicle and CNG station, then enter how many kilograms of CNG you want.</p></div>
      <span className="mobility-heading-icon"><Wallet size={22}/></span>
    </div>
    {error && <ErrorMessage>{error}</ErrorMessage>}
    {notice && <div className="mobility-success"><Check size={16}/>{notice}</div>}
    <div className="fuel-workflow">
      <section className="mobility-card">
        <div className="mobility-card-heading"><div><span className="mobility-eyebrow">STEP 1</span><h2>Choose before refuelling</h2></div><span className="step-number">01</span></div>
        <form className="mobility-form" onSubmit={requestRefuel}>
          <label>Current vehicle<select required value={vehicleId} onChange={event => setVehicleId(event.target.value)}>
            <option value="">Select a CNG-fitted vehicle</option>{eligibleVehicles.map(vehicle => <option key={vehicle.id} value={vehicle.id}>{vehicle.nickname || vehicle.registrationNumber} · {vehicle.registrationNumber}{vehicle.isDefault ? " · default" : ""}</option>)}
          </select>{eligibleVehicles.length === 0 && <small className="mobility-help">Add a vehicle and mark its driver-reported CNG fitment in <Link href="/vehicles">Your vehicles</Link>.</small>}</label>
          <label>Station<select required value={stationId} onChange={event => setStationId(event.target.value)}>
            <option value="">Choose a station</option>{stations.map(station => <option key={station.id} value={station.id} disabled={station.pricePerKg == null || station.pricePerKg <= 0 || station.stockKg == null || station.stockKg <= 0}>{station.stationName}{station.pricePerKg == null ? " · price not reported" : station.stockKg == null || station.stockKg <= 0 ? " · stock unavailable" : ` · ${money(station.pricePerKg)}/kg`}</option>)}
          </select></label>
          <label>How much CNG do you want? (kg)<input required type="number" min="0.01" max="500" step="0.01" value={requestedKg} onChange={event => setRequestedKg(event.target.value)} placeholder="Enter quantity, e.g. 5 or 10" /><small className="mobility-help">Enter the quantity you want the station to dispense. Maximum 500 kg per request.</small></label>
          {selectedStation && <div className="fuel-station-meta"><div><small>REPORTED STOCK</small><b>{selectedStation.stockKg == null ? "Not reported" : `${selectedStation.stockKg} kg`}</b></div><div><small>PRICE / KG</small><b>{money(selectedStation.pricePerKg)}</b></div><div><small>APPROVED DISCOUNT</small><b>{selectedStation.discountPercent ? `${selectedStation.discountPercent}%` : "None"}</b></div></div>}
          {selectedStation?.demoData && <p className="mobility-caution">Demo station figures only. Confirm stock and price with the supplier; these values are not live.</p>}
          <div className="mobility-note"><ShieldCheck size={16}/><span>The supplier sees your requested kg and confirms once the requested amount has been dispensed. Stock is deducted once on confirmation.</span></div>
          <button className="mobility-button" disabled={busy || loading || !eligibleVehicles.length || !selectedStation || selectedStation.pricePerKg == null || selectedStation.stockKg == null || selectedStation.stockKg <= 0 || !Number.isFinite(Number(requestedKg)) || Number(requestedKg) <= 0 || Number(requestedKg) > 500 || Number(requestedKg) > (selectedStation?.stockKg ?? 0)}>{busy ? "Saving…" : "Request this quantity"} <ArrowRight size={15}/></button>
        </form>
      </section>
      <section className="mobility-card">
        <div className="mobility-card-heading"><div><span className="mobility-eyebrow">STEP 2</span><h2>Payment and receipt</h2></div><span className="step-number">02</span></div>
        <div className="mobility-note test-note"><ShieldCheck size={16}/><span>Local test mode only. The test simulator does not contact a payment network or charge real money.</span></div>
        <p className="mobility-muted">After the supplier confirms that your requested quantity was dispensed, the final bill uses the station’s current price and approved discount. Use the test button below only for local demo checks.</p>
      </section>
    </div>
    <section className="mobility-card transaction-history">
      <div className="mobility-card-heading"><div><span className="mobility-eyebrow">YOUR ACCOUNT</span><h2>Refuel history</h2></div><button className="mobility-button secondary small-button" onClick={() => void reload()}><Clock3 size={14}/> Refresh</button></div>
      {loading ? <p className="mobility-muted">Loading history…</p> : transactions.length ? <div className="transaction-list">
        {transactions.map(transaction => <article className="transaction-card" key={transaction.id}>
          <div className="transaction-top"><div><b>{transaction.stationName}</b><small>{transaction.nickname || transaction.registrationNumber} · {dateTime(transaction.createdAt)}</small></div><span className={`transaction-status ${transaction.status === "paid_test" ? "is-paid" : transaction.status === "confirmed" ? "is-confirmed" : ""}`}>{transaction.status === "awaiting_confirmation" ? "Awaiting supplier" : transaction.status === "paid_test" ? "TEST PAID" : transaction.status === "confirmed" ? "Ready to pay" : transaction.status}</span></div>
          {transaction.actualKg != null && transaction.unitPrice != null && <div className="receipt-details">
            <div><small>DISPENSED</small><b>{transaction.actualKg.toFixed(2)} kg</b></div><div><small>PRICE / KG</small><b>{money(transaction.unitPrice)}</b></div><div><small>DISCOUNT</small><b>{transaction.discountPercent}%</b></div><div><small>TOTAL</small><b>{money(transaction.totalAmount)}</b></div>
          </div>}
          {transaction.actualKg != null && <div className="receipt-line"><span>Receipt {transaction.receiptCode || `CNG-${transaction.id}`}</span><span>{transaction.stockDeducted ? "Stock updated once" : "Stock pending"}</span></div>}
          {transaction.status === "confirmed" && <div className="transaction-actions"><button className="mobility-button" disabled={busy} onClick={() => void payTest(transaction.id)}>Complete test payment <Wallet size={15}/></button><button className="mobility-button secondary" onClick={() => window.print()}><Printer size={15}/> Print receipt</button></div>}
          {transaction.paymentStatus === "test_paid" && <p className="mobility-muted">Test reference: {transaction.paymentReference} · Server-verified local simulation · No real charge.</p>}
        </article>)}
      </div> : <div className="mobility-empty"><Fuel size={22}/><b>No refuels recorded yet</b><span>Requests and confirmed digital receipts will appear here.</span></div>}
    </section>
  </div>;
}

export function SupplierRefuelPanel() {
  const [rows, setRows] = useState<FuelTransaction[]>([]);
  const [stations, setStations] = useState<SupplierStation[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function reload() {
    setLoading(true);
    try {
      const [transactions, stationRows] = await Promise.all([
        api<FuelTransaction[]>("/api/supplier/fuel-transactions"),
        api<SupplierStation[]>("/api/supplier/station-discounts"),
      ]);
      setRows(transactions);
      setStations(stationRows);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not load supplier refuel reports.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void reload(); }, []);

  async function saveDiscount(stationId: number, discountPercent: number) {
    setError(""); setNotice("");
    try {
      await api(`/api/supplier/stations/${stationId}/discount`, {
        method: "PATCH", body: JSON.stringify({ discountPercent }),
      });
      setNotice("Station discount updated. It will be saved with the next supplier-confirmed bill.");
      await reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not update the station discount.");
    }
  }

  async function confirm(transaction: FuelTransaction) {
    if (transaction.actualKg == null || transaction.actualKg <= 0) {
      setError("This request has no valid driver-requested quantity.");
      return;
    }
    setBusyId(transaction.id); setError(""); setNotice("");
    try {
      await api(`/api/supplier/fuel-transactions/${transaction.id}/confirm`, {
        method: "PATCH", body: JSON.stringify({}),
      });
      setNotice(`Refuel ${transaction.id} confirmed for ${transaction.actualKg.toFixed(2)} kg; stock was updated once.`);
      await reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not confirm this refuel.");
    } finally {
      setBusyId(null);
    }
  }

  return <section className="mobility-card supplier-refuel-panel">
    <div className="mobility-card-heading"><div><span className="mobility-eyebrow">SUPPLIER REPORTS</span><h2>Refuel confirmations</h2></div><button className="mobility-button secondary small-button" onClick={() => void reload()}><Clock3 size={14}/> Refresh</button></div>
    <p className="mobility-muted">The driver enters the quantity they want. Review the requested kg, dispense that amount, then confirm. Confirmation updates stock once and creates the driver’s bill.</p>
    {error && <ErrorMessage>{error}</ErrorMessage>}{notice && <div className="mobility-success"><Check size={16}/>{notice}</div>}
    <div className="discount-list">{stations.map(station => <div className="discount-row" key={station.id}><div><b>{station.stationName}</b><small>Price {money(station.pricePerKg)} / kg · reported stock {station.stockKg == null ? "unknown" : `${station.stockKg} kg`}</small></div><label>Approved discount<select value={station.discountPercent} onChange={event => void saveDiscount(station.id, Number(event.target.value))}><option value={0}>No discount</option><option value={5}>5%</option><option value={7.5}>7.5%</option><option value={10}>10%</option></select></label></div>)}</div>
    {loading ? <p className="mobility-muted">Loading refuel requests…</p> : rows.length ? <div className="transaction-list">
      {rows.map(row => <article className="transaction-card" key={row.id}>
        <div className="transaction-top"><div><b>{row.stationName}</b><small>{row.userName || "Driver"} · {row.nickname || row.registrationNumber} · {dateTime(row.createdAt)}</small></div><span className={`transaction-status ${row.status === "paid_test" ? "is-paid" : row.status === "confirmed" ? "is-confirmed" : ""}`}>{row.status === "awaiting_confirmation" ? "Needs confirmation" : row.status === "paid_test" ? "TEST PAID" : row.status}</span></div>
        {row.status === "awaiting_confirmation" ? <form className="confirm-refuel-form" onSubmit={event => { event.preventDefault(); void confirm(row); }}>
          <div className="receipt-details"><div><small>DRIVER REQUESTED</small><b>{row.actualKg?.toFixed(2) ?? "—"} kg</b></div><div><small>PRICE / KG</small><b>{money(stations.find(item => item.id === row.stationId)?.pricePerKg)}</b></div><div><small>DISCOUNT</small><b>{stations.find(item => item.id === row.stationId)?.discountPercent ?? 0}%</b></div></div>
          <span className="mobility-help">Confirm only after dispensing the requested amount. If you cannot supply it, do not confirm.</span>
          <button className="mobility-button" disabled={busyId === row.id}>{busyId === row.id ? <><LoaderCircle size={15}/> Saving…</> : <>Confirm supplied amount <Check size={15}/></>}</button>
        </form> : <div className="receipt-details"><div><small>DISPENSED</small><b>{row.actualKg?.toFixed(2)} kg</b></div><div><small>PRICE / KG</small><b>{money(row.unitPrice)}</b></div><div><small>DISCOUNT</small><b>{row.discountPercent}%</b></div><div><small>BILL</small><b>{money(row.totalAmount)}</b></div></div>}
      </article>)}
    </div> : <div className="mobility-empty"><Fuel size={22}/><b>No refuel requests yet</b><span>Driver requests for your assigned stations appear here.</span></div>}
  </section>;
}

export function AdminFuelPanel() {
  const [rows, setRows] = useState<FuelTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  async function reload() {
    setLoading(true);
    try {
      setRows(await api<FuelTransaction[]>("/api/admin/fuel-transactions"));
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Could not load fuel reports.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => { void reload(); }, []);
  const paid = rows.filter(row => row.paymentStatus === "test_paid");
  const totalKg = rows.reduce((sum, row) => sum + (row.actualKg ?? 0), 0);
  const testRevenue = paid.reduce((sum, row) => sum + (row.totalAmount ?? 0), 0);
  return <section className="mobility-card admin-fuel-panel">
    <div className="mobility-card-heading"><div><span className="mobility-eyebrow">NETWORK CONTROL</span><h2>Fuel transactions</h2></div><button className="mobility-button secondary small-button" onClick={() => void reload()}><Clock3 size={14}/> Refresh</button></div>
    {error && <ErrorMessage>{error}</ErrorMessage>}
    <div className="fuel-report-metrics"><div><small>RECORDS LOADED</small><b>{rows.length}</b></div><div><small>CONFIRMED VOLUME</small><b>{totalKg.toFixed(2)} kg</b></div><div><small>TEST-MODE BILLS</small><b>{paid.length}</b></div><div><small>TEST TOTAL</small><b>{money(testRevenue)}</b></div></div>
    <div className="mobility-note test-note"><ShieldCheck size={16}/><span>Payments marked TEST PAID are local simulations only, not actual gateway settlements.</span></div>
    {loading ? <p className="mobility-muted">Loading transactions…</p> : rows.length ? <div className="admin-fuel-list">{rows.map(row => <div className="admin-fuel-row" key={row.id}><div><b>{row.stationName}</b><small>{row.userName} · {row.registrationNumber} · {dateTime(row.createdAt)}</small></div><span>{row.actualKg == null ? "Awaiting kg" : `${row.actualKg.toFixed(2)} kg`}</span><b>{money(row.totalAmount)}</b><span className={`transaction-status ${row.paymentStatus === "test_paid" ? "is-paid" : ""}`}>{row.paymentStatus === "test_paid" ? "TEST PAID" : row.status}</span></div>)}</div> : <div className="mobility-empty"><Wallet size={22}/><b>No transactions recorded</b><span>Supplier-confirmed refuels will appear here.</span></div>}
  </section>;
}
