import { useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import { useForm } from 'react-hook-form';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity, ArrowDownUp, ArrowLeft, ArrowRight, ArrowUpRight, Bookmark, BookmarkCheck,
  Check, ChevronDown, CircleAlert, Clock3, Fuel, MapPin, Menu, MessageSquare,
  Navigation, Phone, Plus, RefreshCw, Route as RouteIcon, Search, ShieldCheck, Star, Store,
  Truck, UserRound, Users, Wallet, X, Zap,
} from 'lucide-react';
import { AdminFuelPanel, FuelHistoryPage, SupplierRefuelPanel, VehiclePage } from './MobilityFeatures';
import {
  getGetAdminSummaryQueryKey, getGetCurrentUserQueryKey,
  getGetStationQueryKey, getListAdminActivityQueryKey,
  getListAdminReviewsQueryKey, getListAdminStationsQueryKey, getListStationReviewsQueryKey,
  getListStationsQueryKey, getListSupplierStationsQueryKey, getListUsersQueryKey,
  useCreateManagedUser, useCreateStation, useCreateStationReview, useDeleteReview,
  useDeleteStation, useGetAdminSummary, useGetCurrentUser, useGetRecommendation,
  useGetStation, useListAdminActivity, useListAdminReviews, useListAdminStations,
  useListStationReviews, useListStations, useListSupplierStations, useListUsers,
  useLoginUser, useLogoutUser, useRegisterUser, useUpdateAvailability,
  useUpdateStation, useUpdateSupplierAvailability,
} from '@workspace/api-client-react';
import type { AvailabilityInput, Review, Station } from '@workspace/api-client-react';

const client = new QueryClient();
const navItems = [
  { href: '/', label: 'Find fuel', icon: Search },
  { href: '/saved', label: 'Saved stations', icon: Bookmark },
];
const freshness = (stamp?: string | null) => {
  if (!stamp) return 'No update recorded';
  const mins = Math.max(0, Math.floor((Date.now() - new Date(stamp).getTime()) / 60000));
  if (mins < 1) return 'Updated just now';
  if (mins < 60) return `Updated ${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  return hrs < 24 ? `Updated ${hrs} hr${hrs > 1 ? 's' : ''} ago` : `Updated ${Math.floor(hrs / 24)} days ago`;
};
const statusLabel = (value: string) => value === 'AVAILABLE' ? 'Available' : value === 'LOW' ? 'Running low' : 'Unavailable';
const statusClass = (value: string) => value === 'AVAILABLE' ? 'status-good' : value === 'LOW' ? 'status-low' : 'status-off';
const time = (value?: string | null) => value ? new Date(value).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : 'Not reported';
const DEMO_LOW_STOCK_THRESHOLD_KG = 100;
const statusFromSampleStock = (stockKg: number) => stockKg <= 0 ? 'NOT_AVAILABLE' : stockKg <= DEMO_LOW_STOCK_THRESHOLD_KG ? 'LOW' : 'AVAILABLE';

function Shell({ children }: { children: React.ReactNode }) {
  const [loc] = useLocation();
  const [mobileNav, setMobileNav] = useState(false);
  const { data: auth } = useGetCurrentUser();
  const logout = useLogoutUser();
  const qc = useQueryClient();
  const role = auth?.user?.role;
  useEffect(() => {
    const stream = new EventSource('/api/availability/events');
    stream.onmessage = (event) => {
      qc.invalidateQueries({ queryKey: getListStationsQueryKey() });
      qc.invalidateQueries({ queryKey: getListAdminStationsQueryKey() });
      qc.invalidateQueries({ queryKey: getListSupplierStationsQueryKey() });
      qc.invalidateQueries({ queryKey: getGetAdminSummaryQueryKey() });
      qc.invalidateQueries({ queryKey: getListAdminActivityQueryKey() });
      try {
        const payload = JSON.parse(event.data) as { stationId?: number };
        if (typeof payload.stationId === 'number') {
          qc.invalidateQueries({ queryKey: getGetStationQueryKey(payload.stationId) });
        }
      } catch {
        // Ignore malformed events and keep the live connection open.
      }
    };
    return () => stream.close();
  }, [qc]);
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
      <Link href="/" className="brand-lockup" data-testid="link-brand">
        <span className="brand-mark"><Fuel size={21}/></span><span><b>CNG<span>Connect</span></b><small>BELAGAVI NETWORK</small></span>
      </Link>
      <div className="side-caption">DRIVER TOOLS</div>
      <nav className="side-nav">
        {navItems.map(({href,label,icon:Icon}) => <Link key={href} href={href} className={`side-link ${loc === href ? 'side-active' : ''}`} data-testid={`link-nav-${href === '/' ? 'finder' : 'saved'}`} onClick={() => setMobileNav(false)}><Icon size={18}/>{label}</Link>)}
        {role === 'user' && <Link href="/vehicles" className={`side-link ${loc === '/vehicles' ? 'side-active' : ''}`} data-testid="link-nav-vehicles" onClick={() => setMobileNav(false)}><Truck size={18}/>Your vehicles</Link>}
        {role === 'user' && <Link href="/fuel-history" className={`side-link ${loc === '/fuel-history' ? 'side-active' : ''}`} data-testid="link-nav-fuel-history" onClick={() => setMobileNav(false)}><Wallet size={18}/>Fuel activity</Link>}
      </nav>
      {role === 'supplier' && <><div className="side-caption">OPERATIONS</div><Link className={`side-link ${loc === '/supplier' ? 'side-active' : ''}`} href="/supplier" data-testid="link-nav-supplier"><Store size={18}/>Megha Gas panel</Link></>}
      {role === 'admin' && <><div className="side-caption">NETWORK CONTROL</div><Link className={`side-link ${loc === '/admin' ? 'side-active' : ''}`} href="/admin" data-testid="link-nav-admin"><ShieldCheck size={18}/>Administration</Link></>}
      <div className="side-bottom">
        <div className="network-note"><span className="live-dot"/><div><b>Belagavi demo data</b><small>Status derives from stock</small></div></div>
        {auth?.user ? <div className="user-panel"><span className="user-avatar">{auth.user.name.slice(0,1).toUpperCase()}</span><div className="user-info"><b>{auth.user.name}</b><small>{auth.user.role}</small></div><button className="icon-button" title="Sign out" data-testid="button-logout" onClick={() => logout.mutate(undefined,{onSuccess:()=>qc.setQueryData(getGetCurrentUserQueryKey(),{authenticated:false,user:null})})}><ArrowUpRight size={16}/></button></div> : <Link className="signin-link" href="/login" data-testid="link-login"><UserRound size={16}/> Sign in</Link>}
        <p className="side-foot">A clearer picture before you pull in.</p>
      </div>
    </aside>
    <div className="main-column">
      <header className="topbar">
        <button className="mobile-menu icon-button" aria-label="Open navigation" data-testid="button-mobile-menu" onClick={() => setMobileNav(!mobileNav)}><Menu size={20}/></button>
        <div className="crumb"><span>Belagavi</span><span className="crumb-slash">/</span><b>{loc === '/' ? 'Station finder' : loc === '/saved' ? 'Saved stations' : loc === '/vehicles' ? 'Your vehicles' : loc === '/fuel-history' ? 'Fuel activity' : loc === '/supplier' ? 'Supplier operations' : loc === '/admin' ? 'Network administration' : 'Station information'}</b></div>
        <div className="top-live"><span className="live-dot"/> DEMO STOCK</div>
      </header>
      <main className="page-content">{children}</main>
      <footer className="app-footer"><span>CNGConnect <i>·</i> Belagavi</span><span>Confirm at station before departure</span></footer>
    </div>
  </div>;
}

function PageHeading({ eyebrow, title, detail, action }: { eyebrow: string; title: string; detail?: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{detail && <p>{detail}</p>}</div>{action}</div>;
}
function AvailabilityPill({ value }: { value: string }) { return <span className={`availability-pill ${statusClass(value)}`} data-testid={`status-availability-${value.toLowerCase()}`}><i/>{statusLabel(value)}</span>; }
function StationCard({ station, saved, onSave, compact = false }: { station: Station; saved: boolean; onSave: (id: number) => void; compact?: boolean }) {
  return <article className={`station-card ${compact ? 'station-card-compact' : ''}`} data-testid={`card-station-${station.id}`}>
    <div className="station-card-top">
      <div className="station-symbol"><Fuel size={20}/></div>
      <div className="station-title-wrap"><div className="station-title-line"><Link href={`/station/${station.id}`} className="station-title" data-testid={`link-station-${station.id}`}>{station.stationName}</Link>{station.demoData&&<span className="demo-tag">SAMPLE DATA</span>}</div><div className="station-address"><MapPin size={13}/>{station.address}</div></div>
      <button className={`save-button ${saved ? 'is-saved' : ''}`} title={saved ? 'Remove saved station' : 'Save station'} onClick={() => onSave(station.id)} data-testid={`button-save-${station.id}`}>{saved ? <BookmarkCheck size={17}/> : <Bookmark size={17}/>}</button>
    </div>
    <div className="station-meta"><AvailabilityPill value={station.availability}/>{station.distanceKm != null && <span className="distance">{station.distanceKm.toFixed(1)} km away</span>}<span className="rating"><Star size={14} fill="currentColor"/>{station.rating.toFixed(1)} <small>({station.reviewCount})</small></span></div>
    <div className="stock-strip"><div><small>{station.demoData ? 'SAMPLE STOCK' : 'REPORTED STOCK'}</small><b>{station.stockKg != null ? `${station.stockKg} kg` : 'Not shared'}</b></div><div><small>PRICE / KG</small><b>{station.pricePerKg != null ? `₹${station.pricePerKg.toFixed(2)}` : 'Not shared'}</b></div><div className="freshness"><Clock3 size={13}/>{station.demoData ? 'Simulated' : freshness(station.availabilityUpdatedAt)}</div></div>
    {station.availabilityNote && <p className="availability-note">{station.availabilityNote}</p>}
    <div className="station-card-bottom"><span><Clock3 size={14}/>{station.openingTime} – {station.closingTime}</span><Link href={`/station/${station.id}`} className="text-link" data-testid={`link-details-${station.id}`}>Details <ArrowRight size={15}/></Link></div>
  </article>;
}
function LoadingRows() { return <div className="skeleton-stack" aria-label="Loading stations"><div className="skeleton skel-wide"/><div className="skeleton skel-short"/><div className="skeleton skel-wide"/></div>; }
function ErrorNotice({ retry }: { retry: () => void }) { return <div className="empty-state"><CircleAlert size={26}/><h3>Couldn’t load this just now</h3><p>Check your connection and try again.</p><Button variant="outline" onClick={retry} data-testid="button-retry"><RefreshCw size={15}/> Try again</Button></div>; }

function useRoleGate(required: 'supplier' | 'admin' | 'user') {
  const { data: auth, isLoading } = useGetCurrentUser();
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (isLoading) return;
    if (!auth?.authenticated || !auth.user) {
      setLocation('/login');
      return;
    }
    if (auth.user.role !== required) {
      setLocation(auth.user.role === 'admin' ? '/admin' : auth.user.role === 'supplier' ? '/supplier' : '/');
    }
  }, [auth, isLoading, required, setLocation]);
  return !isLoading && auth?.authenticated && auth.user?.role === required;
}

function FinderPage() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('ALL');
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationMessage, setLocationMessage] = useState('');
  const [locationPending, setLocationPending] = useState(false);
  const [sort, setSort] = useState<'distance' | 'rating' | 'name'>('rating');
  const [saved, setSaved] = useState<number[]>(() => JSON.parse(localStorage.getItem('cng-saved') || '[]'));
  const params = useMemo(() => ({ ...(search.trim() ? {search: search.trim()} : {}), ...(filter !== 'ALL' ? {availability: filter as 'AVAILABLE'|'LOW'|'NOT_AVAILABLE'} : {}), ...(location ? {latitude:location.latitude,longitude:location.longitude} : {}), sort: location ? sort : sort === 'distance' ? 'rating' : sort }), [search,filter,sort,location]);
  const stations = useListStations(params);
  const recommendation = useGetRecommendation(location ? {latitude:location.latitude,longitude:location.longitude} : undefined);
  const list = stations.data ?? [];
  function requestLocation() {
    if (!navigator.geolocation) {
      setLocationMessage('Location isn’t available in this browser. You can still browse stations by rating or name.');
      return;
    }
    setLocationPending(true);
    setLocationMessage('');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({latitude:position.coords.latitude,longitude:position.coords.longitude});
        setSort('distance');
        setLocationMessage('Nearest matching is now based on your current location.');
        setLocationPending(false);
      },
      () => {
        setLocation(null);
        setSort('rating');
        setLocationMessage('Location permission wasn’t granted. Browse by rating or name, or try location again.');
        setLocationPending(false);
      },
      {enableHighAccuracy:false,timeout:10000,maximumAge:300000},
    );
  }
  function toggleSave(id: number) {
    const next = saved.includes(id) ? saved.filter((x) => x !== id) : [...saved,id];
    setSaved(next); localStorage.setItem('cng-saved', JSON.stringify(next));
  }
  return <div className="finder-page">
    <section className="finder-banner">
      <div className="banner-copy"><div className="eyebrow eyebrow-light">CNG, WITHOUT THE GUESSWORK</div><h1>Know before<br/>you <em>go.</em></h1><p>Sample stock figures for Belagavi stations. Status is calculated automatically; this is not a live fuel feed.</p><div className="banner-trust"><span><ShieldCheck size={15}/> Demo values</span><span><Clock3 size={15}/> LOW at 100 kg or less</span></div></div>
      <div className="banner-art" aria-hidden="true"><div className="art-ring ring-one"/><div className="art-ring ring-two"/><div className="art-orbit orbit-a"/><div className="art-orbit orbit-b"/><div className="art-pin"><Fuel size={28}/></div><span className="map-label label-one">BELAGAVI</span><span className="map-label label-two">NH 48</span><i className="pin-dot pin-a"/><i className="pin-dot pin-b"/></div>
      <span className="banner-coordinate">15°50' N&nbsp;&nbsp; 74°30' E</span>
    </section>
    <div className="finder-toolbar">
      <div className="search-field"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search station or area" aria-label="Search station or area" data-testid="input-station-search"/>{search && <button onClick={()=>setSearch('')} data-testid="button-clear-search"><X size={15}/></button>}</div>
      <button className={`location-button ${location?'location-active':''}`} onClick={requestLocation} disabled={locationPending} data-testid="button-use-location"><MapPin size={15}/>{locationPending?'Finding you…':location?'Location on':'Use my location'}</button>
      <label className="sort-control"><ArrowDownUp size={15}/><select value={sort} onChange={e=>setSort(e.target.value as typeof sort)} aria-label="Sort stations" data-testid="select-station-sort"><option value="rating">Best rated</option><option value="name">Name A–Z</option>{location&&<option value="distance">Nearest first</option>}</select><ChevronDown size={14}/></label>
    </div>
    <div className="location-context" data-testid="text-location-context"><MapPin size={13}/>{location ? 'Nearest matching uses your current location.' : locationMessage || 'Use your location to match stations by distance. Browsing works without it.'}</div>
    <div className="filter-line"><div className="filter-tabs">{[['ALL','All stations'],['AVAILABLE','Available'],['LOW','Running low'],['NOT_AVAILABLE','Unavailable']].map(([key,label])=><button key={key} className={`filter-tab ${filter===key?'filter-selected':''}`} onClick={()=>setFilter(key)} data-testid={`button-filter-${key.toLowerCase()}`}>{label}{filter===key && <i/>}</button>)}</div><span className="result-count" data-testid="text-station-count">{stations.isLoading ? 'Checking stations…' : `${list.length} ${list.length===1?'station':'stations'}`}</span></div>
    {stations.isLoading ? <LoadingRows/> : stations.isError ? <ErrorNotice retry={()=>stations.refetch()}/> : list.length === 0 ? <div className="empty-state"><div className="empty-icon"><Search size={24}/></div><h3>No stations match that search</h3><p>Try a different station name or clear the availability filter.</p><Button variant="outline" onClick={()=>{setSearch('');setFilter('ALL')}} data-testid="button-reset-filters">Clear filters</Button></div> : <div className="finder-layout">
      <section className="station-results" aria-label="Station results">
        {list.map(station=><StationCard key={station.id} station={station} saved={saved.includes(station.id)} onSave={toggleSave}/>)}
      </section>
      <aside className="finder-aside">
        <div className="recommend-card"><div className="recommend-icon"><Zap size={18}/></div><div className="eyebrow">{location?'LOCATION MATCH':'STATION PICK'}</div><h3>A station with availability to consider.</h3>{recommendation.isLoading ? <div className="skeleton skel-short"/> : recommendation.data ? <><b>{recommendation.data.station.stationName}</b><p>{recommendation.data.explanation}</p><Link href={`/station/${recommendation.data.station.id}`} className="recommend-link" data-testid="link-recommendation">See station <ArrowRight size={15}/></Link></> : <p>Station suggestions appear when current network data is available.</p>}</div>
        <div className="aside-note"><span className="note-mark"><Activity size={16}/></span><div><b>Availability is time-sensitive</b><p>Look for the update time on each listing. When plans depend on it, a quick call is still the safest check.</p></div></div>
        <Link href="/saved" className="saved-aside-link" data-testid="link-saved-shortcut"><Bookmark size={16}/> Your saved stations <ArrowRight size={15}/></Link>
      </aside>
    </div>}
  </div>;
}

function SavedPage() {
  const [saved,setSaved]=useState<number[]>(()=>JSON.parse(localStorage.getItem('cng-saved')||'[]'));
  const stations=useListStations();
  const items=(stations.data??[]).filter(s=>saved.includes(s.id));
  function toggleSave(id:number){const next=saved.filter(x=>x!==id);setSaved(next);localStorage.setItem('cng-saved',JSON.stringify(next))}
  return <><PageHeading eyebrow="YOUR SHORTLIST" title="Saved stations" detail="The stops you want to keep close, with the latest reported availability."/><div className="saved-heading-meta"><BookmarkCheck size={17}/>{items.length} saved</div>
    {stations.isLoading?<LoadingRows/>:stations.isError?<ErrorNotice retry={()=>stations.refetch()}/>:items.length?<div className="saved-list">{items.map(s=><StationCard key={s.id} station={s} saved onSave={toggleSave}/>)}</div>:<div className="empty-state"><div className="empty-icon"><Bookmark size={24}/></div><h3>Nothing saved yet</h3><p>Save a station from the finder to keep its latest stock and availability handy.</p><Link href="/" className="button-link" data-testid="link-find-stations"><Search size={16}/> Find stations</Link></div>}
  </>;
}
function StationDetailPage() {
  const {id=''}=useParams(); const sid=Number(id); const qc=useQueryClient();
  const [savedIds,setSavedIds]=useState<number[]>(()=>JSON.parse(localStorage.getItem('cng-saved')||'[]'));
  const station=useGetStation(sid,{query:{queryKey:getGetStationQueryKey(sid),enabled:Number.isFinite(sid)}});
  const reviews=useListStationReviews(sid,{query:{queryKey:getListStationReviewsQueryKey(sid),enabled:Number.isFinite(sid)}});
  const addReview=useCreateStationReview();
  const auth=useGetCurrentUser(); const form=useForm<{rating:number;review:string}>({defaultValues:{rating:5,review:''}});
  function saveReview(v:{rating:number;review:string}){addReview.mutate({stationId:sid,data:{rating:Number(v.rating),review:v.review}},{onSuccess:()=>{qc.invalidateQueries({queryKey:getListStationReviewsQueryKey(sid)});qc.invalidateQueries({queryKey:getGetStationQueryKey(sid)});form.reset()}})}
  if(station.isLoading)return <LoadingRows/>; if(station.isError||!station.data)return <ErrorNotice retry={()=>station.refetch()}/>;
  const s=station.data;
  return <><Link href="/" className="back-link" data-testid="link-back-finder"><ArrowLeft size={16}/> Back to finder</Link>
    <section className="detail-hero"><div className="detail-overline"><Fuel size={17}/> BELAGAVI CNG STATION {s.demoData&&<span className="demo-tag">DEMO RECORD</span>}</div><div className="detail-title-row"><div><h1>{s.stationName}</h1><p><MapPin size={15}/>{s.address}</p></div><button className={`save-button save-large ${savedIds.includes(s.id)?'is-saved':''}`} data-testid="button-save-detail" onClick={()=>{const next=savedIds.includes(s.id)?savedIds.filter(x=>x!==s.id):[...savedIds,s.id];setSavedIds(next);localStorage.setItem('cng-saved',JSON.stringify(next))}}>{savedIds.includes(s.id)?<BookmarkCheck/>:<Bookmark/>}<span>{savedIds.includes(s.id)?'Saved':'Save'}</span></button></div>
     <div className="detail-status-row"><AvailabilityPill value={s.availability}/><span className="freshness"><Clock3 size={14}/>{s.demoData?'Simulated sample':freshness(s.availabilityUpdatedAt)}</span><span className="rating"><Star size={15} fill="currentColor"/>{s.rating.toFixed(1)} <small>· {s.reviewCount} reviews</small></span></div>
    </section>
     <div className="detail-grid"><div className="detail-main"><div className="stock-panel"><div><small>{s.demoData?'SAMPLE CNG STOCK':'REPORTED CNG STOCK'}</small><strong>{s.stockKg!=null?`${s.stockKg} kg`:'Not shared'}</strong></div><div><small>CURRENT PRICE PER KG</small><strong>{s.pricePerKg!=null?`₹${s.pricePerKg.toFixed(2)}`:'Not shared'}</strong></div><div><small>AVAILABILITY NOTE</small><p>{s.availabilityNote||'No supplier note has been added.'}</p></div></div>
       <section className="section-block"><div className="section-title"><div><div className="eyebrow">{s.demoData?'DEMO STATUS RULE':'FROM THE FORECOURT'}</div><h2>{s.demoData?'How status is calculated':'Latest update'}</h2></div><span className="freshness"><Clock3 size={14}/>{s.demoData?'Sample value':time(s.availabilityUpdatedAt)}</span></div>{s.demoData?<div className="update-attribution"><span className="attribution-mark"><Store size={17}/></span><span><b>Simulated demo stock</b><small>0 kg = unavailable · 1–100 kg = running low · over 100 kg = available</small></span><span className="verified-label">DEMO</span></div>:<div className="update-attribution"><span className="attribution-mark"><Store size={17}/></span><span><b>{s.availabilityUpdatedBy||s.supplierName||'Station supplier'}</b><small>Availability shared by the supplier</small></span><span className="verified-label"><Check size={13}/> Reported</span></div>}</section>
      <section className="section-block reviews-block"><div className="section-title"><div><div className="eyebrow">DRIVER NOTES</div><h2>Reviews <span className="review-count">{reviews.data?.length??0}</span></h2></div></div>
        {reviews.isLoading?<div className="skeleton skel-wide"/>:reviews.isError?<ErrorNotice retry={()=>reviews.refetch()}/>:reviews.data?.length?<div className="review-list">{reviews.data.map((r:Review)=><article className="review-item" key={r.id} data-testid={`review-${r.id}`}><div className="review-user"><span className="review-avatar">{r.userName.slice(0,1).toUpperCase()}</span><div><b>{r.userName}</b><small>{time(r.createdAt)}</small></div><span className="review-stars">{Array.from({length:5},(_,i)=><Star size={13} key={i} fill={i<r.rating?'currentColor':'none'}/>)}</span></div><p>{r.review}</p></article>)}</div>:<p className="subtle-copy">No driver notes yet. Share a useful first-hand update.</p>}
        {auth.data?.authenticated?<Form {...form}><form className="review-form" onSubmit={form.handleSubmit(saveReview)}><div className="eyebrow">ADD YOUR EXPERIENCE</div><FormField control={form.control} name="rating" render={({field})=><FormItem><FormLabel>Your rating</FormLabel><FormControl><select {...field} onChange={e=>field.onChange(Number(e.target.value))} className="form-input" data-testid="select-review-rating"><option value={5}>5 — Excellent</option><option value={4}>4 — Good</option><option value={3}>3 — Average</option><option value={2}>2 — Poor</option><option value={1}>1 — Very poor</option></select></FormControl><FormMessage/></FormItem>}/><FormField control={form.control} name="review" rules={{required:'Add a few words about your visit.',minLength:{value:3,message:'Please write at least 3 characters.'},maxLength:{value:600,message:'Keep your review under 600 characters.'}}} render={({field})=><FormItem><FormLabel>What should other drivers know?</FormLabel><FormControl><textarea {...field} className="form-input form-textarea" placeholder="Share something specific and helpful…" data-testid="input-review-text"/></FormControl><FormMessage/></FormItem>}/><Button type="submit" disabled={addReview.isPending} data-testid="button-submit-review">{addReview.isPending?'Posting…':'Post review'} <ArrowRight size={15}/></Button></form></Form>:<div className="signin-prompt"><span>Want to leave a driver note?</span><Link href="/login" className="text-link" data-testid="link-login-review">Sign in to review <ArrowRight size={15}/></Link></div>}
      </section>
    </div><aside className="detail-aside"><div className="route-card"><div className="route-card-top"><span className="route-icon"><Navigation size={18}/></span><span className="eyebrow">PLAN YOUR STOP</span></div><h3>Get directions</h3><p>Open this station in your preferred maps app to check the route before setting off.</p><Link href={`/route/${s.id}`} className="button-link button-full" data-testid="link-directions"><RouteIcon size={16}/> View directions <ArrowUpRight size={15}/></Link><Link href={`/fuel-history?station=${s.id}`} className="button-outline-link button-full" data-testid="link-start-refuel"><Fuel size={16}/> Record a refuel</Link><a href={`tel:${s.phone}`} className="phone-link" data-testid="link-call-station"><Phone size={15}/> Call {s.phone}</a></div>
       <div className="hours-card"><div className="eyebrow">STATION HOURS</div><div><Clock3 size={16}/><b>{s.openingTime} – {s.closingTime}</b></div><small>Hours are station-reported and may vary.</small></div><div className="freshness-legend"><ShieldCheck size={17}/><p>{s.demoData?'Demo values only. They do not reflect verified live gas stock.':'Availability is supplier-reported. Freshness is shown so you can judge how current it is.'}</p></div></aside></div>
  </>;
}
function RoutePage() {
 const {id=''}=useParams();const station=useGetStation(Number(id),{query:{queryKey:getGetStationQueryKey(Number(id)),enabled:!!id}});
 if(station.isLoading)return <LoadingRows/>;if(!station.data)return <ErrorNotice retry={()=>station.refetch()}/>;
 const s=station.data;
 return <><Link href={`/station/${s.id}`} className="back-link" data-testid="link-back-station"><ArrowLeft size={16}/> Back to station</Link><div className="route-page"><div className="route-kicker"><Navigation size={16}/> DIRECTIONS</div><h1>On your way to<br/><em>{s.stationName}</em></h1><p className="route-address"><MapPin size={16}/>{s.address}</p><div className="route-summary"><div><small>REPORTED AVAILABILITY</small><AvailabilityPill value={s.availability}/></div><div><small>LAST UPDATED</small><b>{freshness(s.availabilityUpdatedAt)}</b></div><div><small>STATION HOURS</small><b>{s.openingTime} – {s.closingTime}</b></div></div><div className="route-actions"><a className="button-link" href={`https://www.google.com/maps/dir/?api=1&destination=${s.latitude},${s.longitude}`} target="_blank" rel="noreferrer" data-testid="link-open-maps"><Navigation size={17}/> Open directions <ArrowUpRight size={15}/></a><a className="button-outline-link" href={`tel:${s.phone}`} data-testid="link-call-route"><Phone size={16}/> Call station</a></div><div className="route-reminder"><CircleAlert size={18}/><p>Availability can change between updates. If this is a critical stop, call the station before you head out.</p></div><div className="coordinate-note">DESTINATION COORDINATES <b>{s.latitude.toFixed(5)}° N · {s.longitude.toFixed(5)}° E</b></div></div></>;
}

function AuthPage({register=false}:{register?:boolean}) {
 const login=useLoginUser();const signup=useRegisterUser();const [,setLocation]=useLocation();const qc=useQueryClient();
 const form=useForm<{name:string;email:string;password:string}>({defaultValues:{name:'',email:'',password:''}});
 const [error,setError]=useState('');
 const submit=(v:{name:string;email:string;password:string})=>{setError('');const opts={onSuccess:(user:{id:number;name:string;email:string;role:string})=>{qc.setQueryData(getGetCurrentUserQueryKey(),{authenticated:true,user});setLocation(user.role==='admin'?'/admin':user.role==='supplier'?'/supplier':'/');},onError:()=>setError('We couldn’t sign you in with those details. Please check and try again.')};if(register)signup.mutate({data:{name:v.name,email:v.email,password:v.password}},opts);else login.mutate({data:{email:v.email,password:v.password}},opts)};
 const pending=login.isPending||signup.isPending;
 return <div className="auth-wrap"><div className="auth-aside"><div className="auth-emblem"><Fuel size={26}/></div><div className="eyebrow eyebrow-light">CNGCONNECT · BELAGAVI</div><h1>Good trips<br/>start with<br/><em>good info.</em></h1><p>Reliable station updates, from local suppliers to the drivers who need them.</p><div className="auth-aside-bottom"><ShieldCheck size={17}/> Supplier-reported availability. Clear freshness. Fewer surprises.</div></div><div className="auth-form-side"><Link href="/" className="back-link" data-testid="link-auth-home"><ArrowLeft size={16}/> Back to station finder</Link><div className="auth-form-content"><div className="eyebrow">{register?'JOIN THE NETWORK':'WELCOME BACK'}</div><h2>{register?'Create your account':'Sign in'}</h2><p>{register?'Save stations and share helpful driver notes.':'Your Belagavi CNG network, ready when you are.'}</p>
  <Form {...form}><form onSubmit={form.handleSubmit(submit)} className="auth-form">
    {register&&<FormField control={form.control} name="name" rules={{required:'Enter your name.',minLength:{value:2,message:'Name must be at least 2 characters.'}}} render={({field})=><FormItem><FormLabel>Your name</FormLabel><FormControl><input {...field} className="form-input" placeholder="Name as you’d like it shown" autoComplete="name" data-testid="input-name"/></FormControl><FormMessage/></FormItem>}/>}
    <FormField control={form.control} name="email" rules={{required:'Enter your email address.',pattern:{value:/^[^\s@]+@[^\s@]+\.[^\s@]+$/,message:'Enter a valid email address.'}}} render={({field})=><FormItem><FormLabel>Email address</FormLabel><FormControl><input {...field} type="email" className="form-input" placeholder="you@example.com" autoComplete="email" data-testid="input-email"/></FormControl><FormMessage/></FormItem>}/>
    <FormField control={form.control} name="password" rules={{required:'Enter your password.',minLength:{value:register?8:1,message:'Password must be at least 8 characters.'}}} render={({field})=><FormItem><FormLabel>Password</FormLabel><FormControl><input {...field} type="password" className="form-input" placeholder="Enter your password" autoComplete={register?'new-password':'current-password'} data-testid="input-password"/></FormControl><FormMessage/></FormItem>}/>
    {error&&<div className="form-error" data-testid="status-auth-error"><CircleAlert size={15}/>{error}</div>}
    <Button className="auth-submit" type="submit" disabled={pending} data-testid="button-auth-submit">{pending?'Please wait…':register?'Create account':'Sign in'} <ArrowRight size={16}/></Button>
  </form></Form><div className="auth-switch">{register?'Already have an account?':'New to CNGConnect?'} <Link href={register?'/login':'/register'} data-testid="link-auth-switch">{register?'Sign in':'Create an account'}</Link></div></div><div className="auth-footer">CNGConnect Belagavi <span>·</span> Practical information for the road.</div></div></div>;
}

function SupplierPage() {
 const qc=useQueryClient();const stations=useListSupplierStations();const update=useUpdateSupplierAvailability();
 const [active,setActive]=useState<number|null>(null);const [feedback,setFeedback]=useState('');
 const selected=stations.data?.find(s=>s.id===active);
 const form=useForm<{availability:string;stockKg:string;pricePerKg:string;availabilityNote:string}>({defaultValues:{availability:'AVAILABLE',stockKg:'',pricePerKg:'',availabilityNote:''}});
 const stockInput=form.watch('stockKg');
 const demoStatusPreview=stockInput===''||!Number.isFinite(Number(stockInput))?selected?.availability||'NOT_AVAILABLE':statusFromSampleStock(Number(stockInput));
 useEffect(()=>{if(selected)form.reset({availability:selected.availability,stockKg:selected.stockKg==null?'':String(selected.stockKg),pricePerKg:selected.pricePerKg==null?'':String(selected.pricePerKg),availabilityNote:selected.availabilityNote||''})},[selected,form]);
 const submit=(v:{availability:string;stockKg:string;pricePerKg:string;availabilityNote:string})=>{if(!active)return;const data:AvailabilityInput={availability:v.availability as AvailabilityInput['availability'],stockKg:v.stockKg===''?null:Number(v.stockKg),pricePerKg:v.pricePerKg===''?null:Number(v.pricePerKg),availabilityNote:v.availabilityNote};update.mutate({stationId:active,data},{onSuccess:()=>{setFeedback('Update published to the Belagavi network.');qc.invalidateQueries({queryKey:getListSupplierStationsQueryKey()});qc.invalidateQueries({queryKey:getListStationsQueryKey()});qc.invalidateQueries({queryKey:getGetStationQueryKey(active)});setTimeout(()=>setFeedback(''),4200)},onError:()=>setFeedback('Could not publish the update. Please try again.')})};
 return <><div className="supplier-brand"><div className="megha-mark"><Fuel size={23}/></div><div><b>MEGHA GAS</b><small>SUPPLIER OPERATIONS · BELAGAVI</small></div><span className="supplier-badge"><span className="live-dot"/> LIVE DESK</span></div>
 <PageHeading eyebrow="STATION OPERATIONS" title="Availability desk" detail="Publish what drivers need to know before they reach the forecourt."/>
 {stations.isLoading?<LoadingRows/>:stations.isError?<ErrorNotice retry={()=>stations.refetch()}/>:!stations.data?.length?<div className="empty-state"><Store size={26}/><h3>No stations assigned</h3><p>Your administrator will assign stations to your supplier account.</p></div>:<div className="supplier-layout"><section className="supplier-stations"><div className="section-topline"><b>Your assigned stations</b><span>{stations.data.length} {stations.data.length===1?'station':'stations'}</span></div>{stations.data.map(s=><button key={s.id} className={`supplier-station ${active===s.id?'supplier-selected':''}`} onClick={()=>setActive(s.id)} data-testid={`button-select-station-${s.id}`}><span className="station-symbol"><Fuel size={18}/></span><span className="supplier-station-info"><b>{s.stationName}</b><small><MapPin size={12}/>{s.address}</small><span className="supplier-status"><AvailabilityPill value={s.availability}/><i>{freshness(s.availabilityUpdatedAt)}</i></span></span><ArrowRight size={16}/></button>)}</section>
 <section className="availability-editor">{selected?<><div className="editor-heading"><div><div className="eyebrow">PUBLISH CURRENT STATUS</div><h2>{selected.stationName}</h2><p>{selected.address}</p></div><span className="editor-stamp"><Clock3 size={13}/>{freshness(selected.availabilityUpdatedAt)}</span></div>
 {feedback&&<div className={feedback.startsWith('Could')?'form-error':'success-banner'} data-testid="status-supplier-feedback">{feedback.startsWith('Could')?<CircleAlert size={16}/>:<Check size={16}/>} {feedback}</div>}
 <Form {...form}><form className="editor-form" onSubmit={form.handleSubmit(submit)}>
  {selected.demoData&&stockInput!==''?<div className="availability-note">Demo status is calculated from the stock amount: <AvailabilityPill value={demoStatusPreview}/> <span>0 kg = unavailable · 1–100 kg = running low · over 100 kg = available.</span></div>:<FormField control={form.control} name="availability" render={({field})=><FormItem><FormLabel>Current availability</FormLabel><FormControl><div className="availability-options">{[['AVAILABLE','Available'],['LOW','Running low'],['NOT_AVAILABLE','Unavailable']].map(([v,l])=><button type="button" key={v} className={`availability-option ${field.value===v?'option-active':''} ${statusClass(v)}`} onClick={()=>field.onChange(v)} data-testid={`button-status-${v.toLowerCase()}`}><i/>{l}</button>)}</div></FormControl><FormMessage/></FormItem>}/>}
 <div className="form-two-col"><FormField control={form.control} name="stockKg" rules={{validate:v=>v===''||Number(v)>=0||'Stock must be 0 or more.'}} render={({field})=><FormItem><FormLabel>Stock on hand <small>(kg)</small></FormLabel><FormControl><input {...field} type="number" min="0" step="0.1" className="form-input" placeholder="Leave blank if unknown" data-testid="input-stock-kg"/></FormControl><FormMessage/></FormItem>}/><FormField control={form.control} name="pricePerKg" rules={{validate:v=>v===''||Number(v)>=0||'Price must be 0 or more.'}} render={({field})=><FormItem><FormLabel>Price per kg <small>(₹)</small></FormLabel><FormControl><input {...field} type="number" min="0" step="0.01" className="form-input" placeholder="Leave blank if unknown" data-testid="input-price-kg"/></FormControl><FormMessage/></FormItem>}/></div>
 <FormField control={form.control} name="availabilityNote" rules={{maxLength:{value:240,message:'Keep the note under 240 characters.'}}} render={({field})=><FormItem><FormLabel>Note for drivers <small>(optional)</small></FormLabel><FormControl><textarea {...field} maxLength={240} className="form-input form-textarea" placeholder="Queue, temporary issue, useful detail…" data-testid="input-availability-note"/></FormControl><div className="field-foot"><FormMessage/><span>{field.value.length}/240</span></div></FormItem>}/>
 <div className="publish-footer"><span><ShieldCheck size={15}/> Visible to drivers across Belagavi</span><Button disabled={update.isPending} type="submit" data-testid="button-publish-availability">{update.isPending?'Publishing…':'Publish update'} <ArrowUpRight size={15}/></Button></div>
  </form></Form></>:<div className="editor-empty"><div className="empty-icon"><ArrowLeft size={21}/></div><h3>Select a station</h3><p>Choose one of your assigned Megha Gas locations to publish a live availability update.</p></div>}</section></div>}
  <SupplierRefuelPanel/>
 </>;
}

 function AdminPage() {
 const qc=useQueryClient();const summary=useGetAdminSummary();const stations=useListAdminStations();const activity=useListAdminActivity();const users=useListUsers();const reviews=useListAdminReviews();
 const createStation=useCreateStation();const updateStation=useUpdateStation();const deleteStation=useDeleteStation();const updateAvailability=useUpdateAvailability();const createUser=useCreateManagedUser();const deleteReview=useDeleteReview();
 const [tab,setTab]=useState<'stations'|'accounts'|'reviews'|'fuel'>('stations');const [modal,setModal]=useState<'station'|'user'|null>(null);const [editing,setEditing]=useState<Station|null>(null);const [notice,setNotice]=useState('');
 const stationForm=useForm<{stationName:string;address:string;latitude:string;longitude:string;phone:string;openingTime:string;closingTime:string; supplierId:string}>({defaultValues:{stationName:'',address:'',latitude:'',longitude:'',phone:'',openingTime:'06:00',closingTime:'22:00',supplierId:''}});
 const userForm=useForm<{name:string;email:string;password:string;role:'supplier'|'admin'}>({defaultValues:{name:'',email:'',password:'',role:'supplier'}});
 const [quickStatus,setQuickStatus]=useState<Record<number,string>>({});
 const closeModal=()=>{setModal(null);setEditing(null);stationForm.reset();userForm.reset()};
 function openStation(s?:Station){setEditing(s||null);stationForm.reset(s?{stationName:s.stationName,address:s.address,latitude:String(s.latitude),longitude:String(s.longitude),phone:s.phone,openingTime:s.openingTime,closingTime:s.closingTime,supplierId:s.supplierId?String(s.supplierId):''}:{stationName:'',address:'',latitude:'',longitude:'',phone:'',openingTime:'06:00',closingTime:'22:00',supplierId:''});setModal('station')}
 const refreshAdmin=()=>{qc.invalidateQueries({queryKey:getListAdminStationsQueryKey()});qc.invalidateQueries({queryKey:getGetAdminSummaryQueryKey()});qc.invalidateQueries({queryKey:getListAdminActivityQueryKey()});qc.invalidateQueries({queryKey:getListStationsQueryKey()})};
 function saveStation(v:{stationName:string;address:string;latitude:string;longitude:string;phone:string;openingTime:string;closingTime:string;supplierId:string}){const data={stationName:v.stationName,address:v.address,latitude:Number(v.latitude),longitude:Number(v.longitude),phone:v.phone,openingTime:v.openingTime,closingTime:v.closingTime,supplierId:v.supplierId?Number(v.supplierId):null};const done=()=>{refreshAdmin();closeModal()};if(editing)updateStation.mutate({stationId:editing.id,data},{onSuccess:done,onError:()=>setNotice('Station changes could not be saved.')});else createStation.mutate({data},{onSuccess:done,onError:()=>setNotice('Station could not be created.')})}
 function updateQuick(s:Station){const next=quickStatus[s.id]||s.availability;if(next===s.availability)return;const data:AvailabilityInput={availability:next as AvailabilityInput['availability'],stockKg:s.stockKg??null,pricePerKg:s.pricePerKg??null,availabilityNote:s.availabilityNote||''};updateAvailability.mutate({stationId:s.id,data},{onSuccess:refreshAdmin})}
 function createManaged(v:{name:string;email:string;password:string;role:'supplier'|'admin'}){createUser.mutate({data:v},{onSuccess:()=>{qc.invalidateQueries({queryKey:getListUsersQueryKey()});qc.invalidateQueries({queryKey:getGetAdminSummaryQueryKey()});closeModal()},onError:()=>setNotice('Account could not be created. Check the details and try again.')})}
 return <><PageHeading eyebrow="NETWORK CONTROL" title="Administration" detail="Station records, supplier accounts and driver feedback in one place." action={tab==='stations'||tab==='accounts'?<Button onClick={()=>tab==='stations'?openStation():setModal('user')} data-testid="button-admin-create"><Plus size={16}/>{tab==='stations'?'Add station':'Add account'}</Button>:undefined}/>
 {summary.isLoading?<div className="metric-grid">{[1,2,3,4].map(x=><div key={x} className="skeleton metric-skeleton"/>)}</div>:summary.data&&<div className="metric-grid" data-testid="admin-summary">{[['Stations',summary.data.totalStations,Fuel],['Available',summary.data.availableStations,Check],['Stale updates',summary.data.staleStations,Clock3],['Accounts',summary.data.totalUsers+summary.data.totalSuppliers,Users]].map(([label,value,Icon]:any)=><div className="metric-card" key={label}><span className="metric-icon"><Icon size={18}/></span><small>{label}</small><b>{value}</b></div>)}</div>}
  {notice&&<div className="form-error" data-testid="status-admin-notice"><CircleAlert size={15}/>{notice}<button onClick={()=>setNotice('')} data-testid="button-dismiss-notice"><X size={14}/></button></div>}
  {tab==='fuel'&&<AdminFuelPanel/>}
  <div className="admin-tabs">{[['stations','Stations'],['accounts','Accounts'],['reviews','Reviews'],['fuel','Fuel reports']].map(([k,l])=><button key={k} onClick={()=>setTab(k as typeof tab)} className={`admin-tab ${tab===k?'admin-tab-active':''}`} data-testid={`button-admin-tab-${k}`}>{l}{k==='reviews'&&reviews.data?.length? <span>{reviews.data.length}</span>:null}</button>)}<button className="admin-refresh" onClick={()=>{summary.refetch();stations.refetch();activity.refetch();users.refetch();reviews.refetch()}} data-testid="button-refresh-admin"><RefreshCw size={15}/> Refresh</button></div>
  {tab==='stations'&&<div className="admin-grid"><section className="admin-table-panel"><div className="panel-title"><div><div className="eyebrow">LOCATION DIRECTORY</div><h2>Station network</h2></div><span>{stations.data?.length??0} locations</span></div>{stations.isLoading?<LoadingRows/>:stations.isError?<ErrorNotice retry={()=>stations.refetch()}/>:!stations.data?.length?<div className="empty-state"><Fuel size={24}/><h3>No station records</h3><p>Add the first location to the network.</p></div>:<div className="station-admin-list">{stations.data.map(s=><div className="admin-station-row" key={s.id} data-testid={`row-admin-station-${s.id}`}><div className="admin-station-main"><span className="station-symbol"><Fuel size={17}/></span><div><b>{s.stationName}</b><small>{s.address}</small><small className="admin-supplier-label">{s.supplierName||'No supplier assigned'} · {s.demoData?'Demo data':freshness(s.availabilityUpdatedAt)}</small></div></div><div className="admin-row-controls">{s.demoData&&s.stockKg!=null?<><AvailabilityPill value={s.availability}/><span className="admin-supplier-label" title="Availability is calculated from demo stock">Auto · {s.stockKg} kg</span></>:<><select value={quickStatus[s.id]||s.availability} onChange={e=>setQuickStatus({...quickStatus,[s.id]:e.target.value})} aria-label={`Availability ${s.stationName}`} data-testid={`select-admin-status-${s.id}`}><option value="AVAILABLE">Available</option><option value="LOW">Running low</option><option value="NOT_AVAILABLE">Unavailable</option></select><button title="Apply availability" className="icon-button" onClick={()=>updateQuick(s)} data-testid={`button-admin-update-status-${s.id}`}><Check size={15}/></button></>}<button title="Edit station" className="icon-button" onClick={()=>openStation(s)} data-testid={`button-admin-edit-${s.id}`}><ArrowUpRight size={15}/></button><button title="Delete station" className="icon-button delete-icon" onClick={()=>{if(confirm(`Delete ${s.stationName}?`))deleteStation.mutate({stationId:s.id},{onSuccess:refreshAdmin})}} data-testid={`button-admin-delete-${s.id}`}><X size={15}/></button></div></div>)}</div>}</section>
 <aside className="activity-panel"><div className="eyebrow">LIVE NETWORK</div><h2>Recent availability</h2>{activity.isLoading?<LoadingRows/>:activity.isError?<ErrorNotice retry={()=>activity.refetch()}/>:activity.data?.length?<div className="activity-list">{activity.data.slice(0,8).map(a=><div className="activity-item" key={a.id} data-testid={`activity-update-${a.id}`}><span className={`activity-dot ${statusClass(a.availability)}`}/><div><b>{a.stationName}</b><small>{statusLabel(a.availability)} · {a.updatedBy}</small><small>{time(a.updatedAt)}</small></div></div>)}</div>:<p className="subtle-copy">No availability updates recorded yet.</p>}</aside></div>}
 {tab==='accounts'&&<section className="admin-table-panel standalone-panel"><div className="panel-title"><div><div className="eyebrow">NETWORK ACCESS</div><h2>Managed accounts</h2></div><span>{users.data?.length??0} accounts</span></div>{users.isLoading?<LoadingRows/>:users.isError?<ErrorNotice retry={()=>users.refetch()}/>:users.data?.length?<div className="account-list">{users.data.map(u=><div className="account-row" key={u.id} data-testid={`row-account-${u.id}`}><span className="user-avatar">{u.name.slice(0,1).toUpperCase()}</span><div><b>{u.name}</b><small>{u.email}</small></div><span className={`role-pill role-${u.role}`}>{u.role}</span></div>)}</div>:<div className="empty-state"><Users size={24}/><h3>No managed accounts</h3><p>Create a supplier or administrator account to manage the network.</p></div>}</section>}
 {tab==='reviews'&&<section className="admin-table-panel standalone-panel"><div className="panel-title"><div><div className="eyebrow">COMMUNITY MODERATION</div><h2>Driver reviews</h2></div><span>{reviews.data?.length??0} reviews</span></div>{reviews.isLoading?<LoadingRows/>:reviews.isError?<ErrorNotice retry={()=>reviews.refetch()}/>:reviews.data?.length?<div className="moderation-list">{reviews.data.map(r=><div className="moderation-review" key={r.id} data-testid={`row-review-${r.id}`}><div className="moderation-header"><div><b>{r.userName}</b><small>Station #{r.stationId} · {time(r.createdAt)}</small></div><span className="review-stars">{Array.from({length:5},(_,i)=><Star size={13} key={i} fill={i<r.rating?'currentColor':'none'}/>)}</span></div><p>{r.review}</p><button className="moderation-remove" onClick={()=>{if(confirm('Remove this review from the network?'))deleteReview.mutate({reviewId:r.id},{onSuccess:()=>qc.invalidateQueries({queryKey:getListAdminReviewsQueryKey()})})}} data-testid={`button-remove-review-${r.id}`}><X size={14}/> Remove review</button></div>)}</div>:<div className="empty-state"><MessageSquare size={24}/><h3>No reviews to moderate</h3><p>Driver feedback will appear here when it is submitted.</p></div>}</section>}
 {modal&&<div className="modal-scrim" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)closeModal()}}><section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-header"><div><div className="eyebrow">{modal==='station'?'LOCATION RECORD':'NETWORK ACCESS'}</div><h2 id="modal-title">{modal==='station'?(editing?'Edit station':'Add a station'):'Create managed account'}</h2></div><button className="icon-button" onClick={closeModal} aria-label="Close" data-testid="button-close-modal"><X size={18}/></button></div>
 {modal==='station'?<Form {...stationForm}><form className="modal-form" onSubmit={stationForm.handleSubmit(saveStation)}>{([
 ['stationName','Station name','Example CNG Station'],['address','Address / area','Street address and area'],['latitude','Latitude','15.8500'],['longitude','Longitude','74.5000'],['phone','Phone','Station contact number'],['openingTime','Opening time','06:00'],['closingTime','Closing time','22:00'],
 ] as const).map(([name,label,placeholder])=><FormField key={name} control={stationForm.control} name={name} rules={{required:`${label} is required.`}} render={({field})=><FormItem className={name==='address'?'modal-span':''}><FormLabel>{label}</FormLabel><FormControl><input {...field} className="form-input" placeholder={placeholder} type={['latitude','longitude'].includes(name)?'number':'text'} step={['latitude','longitude'].includes(name)?'any':undefined} data-testid={`input-station-${name}`}/></FormControl><FormMessage/></FormItem>}/>)}
 <FormField control={stationForm.control} name="supplierId" render={({field})=><FormItem className="modal-span"><FormLabel>Assigned supplier</FormLabel><FormControl><select {...field} className="form-input" data-testid="select-station-supplier"><option value="">Unassigned</option>{(users.data??[]).filter(u=>u.role==='supplier').map(u=><option key={u.id} value={String(u.id)}>{u.name} · {u.email}</option>)}</select></FormControl><FormMessage/></FormItem>}/>
 <div className="modal-actions"><Button variant="outline" type="button" onClick={closeModal} data-testid="button-cancel-modal">Cancel</Button><Button disabled={createStation.isPending||updateStation.isPending} type="submit" data-testid="button-save-station">{editing?'Save changes':'Create station'}</Button></div></form></Form>:<Form {...userForm}><form className="modal-form user-modal-form" onSubmit={userForm.handleSubmit(createManaged)}><FormField control={userForm.control} name="name" rules={{required:'Name is required.',minLength:{value:2,message:'At least 2 characters.'}}} render={({field})=><FormItem><FormLabel>Name</FormLabel><FormControl><input {...field} className="form-input" placeholder="Full name" data-testid="input-managed-name"/></FormControl><FormMessage/></FormItem>}/><FormField control={userForm.control} name="email" rules={{required:'Email is required.',pattern:{value:/^[^\s@]+@[^\s@]+\.[^\s@]+$/,message:'Enter a valid email.'}}} render={({field})=><FormItem><FormLabel>Email address</FormLabel><FormControl><input {...field} type="email" className="form-input" placeholder="person@example.com" data-testid="input-managed-email"/></FormControl><FormMessage/></FormItem>}/><FormField control={userForm.control} name="password" rules={{required:'Password is required.',minLength:{value:8,message:'At least 8 characters.'}}} render={({field})=><FormItem><FormLabel>Temporary password</FormLabel><FormControl><input {...field} type="password" className="form-input" data-testid="input-managed-password"/></FormControl><FormMessage/></FormItem>}/><FormField control={userForm.control} name="role" render={({field})=><FormItem><FormLabel>Role</FormLabel><FormControl><select {...field} className="form-input" data-testid="select-managed-role"><option value="supplier">Supplier</option><option value="admin">Administrator</option></select></FormControl><FormMessage/></FormItem>}/><div className="modal-actions"><Button variant="outline" type="button" onClick={closeModal} data-testid="button-cancel-account">Cancel</Button><Button disabled={createUser.isPending} type="submit" data-testid="button-create-account">Create account</Button></div></form></Form>}</section></div>}
 </>;
}

function DirectionsNotFound() { return <NotFound/>; }
function RoleGuard({ required, children }: { required: 'supplier' | 'admin' | 'user'; children: React.ReactNode }) {
  const allowed = useRoleGate(required);
  return allowed ? <>{children}</> : <LoadingRows/>;
}
function RouterContent() {
 const [loc]=useLocation();
 useEffect(()=>{window.scrollTo({top:0,behavior:'smooth'})},[loc]);
  return <ErrorBoundary resetKey={loc}><Switch><Route path="/" component={FinderPage}/><Route path="/saved" component={SavedPage}/><Route path="/vehicles"><RoleGuard required="user"><VehiclePage/></RoleGuard></Route><Route path="/fuel-history"><RoleGuard required="user"><FuelHistoryPage/></RoleGuard></Route><Route path="/station/:id" component={StationDetailPage}/><Route path="/route/:id" component={RoutePage}/><Route path="/login"><AuthPage/></Route><Route path="/register"><AuthPage register/></Route><Route path="/supplier"><RoleGuard required="supplier"><SupplierPage/></RoleGuard></Route><Route path="/admin"><RoleGuard required="admin"><AdminPage/></RoleGuard></Route><Route component={DirectionsNotFound}/></Switch></ErrorBoundary>;
}
function App() {
 return <QueryClientProvider client={client}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,'')}><Shell><RouterContent/></Shell></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>;
}
export default App;