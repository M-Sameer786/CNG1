# CNGConnect Belagavi

A Belagavi CNG station finder with driver accounts, vehicle records, supplier-confirmed refuels, and role-separated operations panels.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/cngconnect/src/App.tsx` — station finder, station details, route links, authentication, and role panels.
- `artifacts/cngconnect/src/MobilityFeatures.tsx` and `mobility.css` — vehicle garage, driver refuel history/receipts, supplier confirmations, and admin fuel reporting.
- `artifacts/api-server/src/routes/cngconnect.ts` — auth, station, supplier, admin, vehicle, refuel, and test-payment routes.
- `lib/db/src/schema/cngconnect.ts` — Drizzle PostgreSQL schema.
- `lib/db/migrations/0001_driver_vehicles_and_fuel.sql` — equivalent SQL migration for the added vehicle and fuel tables.
- `lib/api-spec/openapi.yaml` — source OpenAPI contract for the original generated station API.

## Architecture decisions

- Keep the existing pnpm workspace, Express API, React/Vite UI, PostgreSQL database, and cookie-session authentication.
- Vehicle fitment is driver-reported data; vehicle category alone never establishes CNG compatibility.
- Refuel stock deduction happens only after supplier confirmation, and the transaction and stock update commit together under database row locks.
- Idempotency keys protect driver requests; state transitions prevent duplicate stock deductions.
- The local payment simulator is test-only and disabled in production. It is not a real payment processor.

## Product

Drivers can locate stations, save stations, manage multiple vehicles, request refuel records, and receive a digital receipt after the supplier confirms dispensed kg. Suppliers publish station availability, price, approved discounts, and confirm dispenser readings. Admins manage accounts/stations and review transaction reports. Seed station availability and stock are demo data; production values must be supplier-reported.

## User preferences

- Preserve the existing project, framework, database, API, and working features when making changes.
- Keep supplier/admin panels protected from ordinary driver accounts.
- Do not present guessed stock, price, compatibility, quantities, or payment status as verified.

## Gotchas

- Set `DATABASE_URL` before starting the server or running `pnpm db:push`.
- Seeded station data and stock are illustrative. Suppliers must report a price before a refuel request can be recorded.
- `CNGCONNECT_PAYMENT_MODE=test` enables only a local no-charge simulator; never treat its `TEST PAID` status as a real settlement.
- Production startup requires `CNGCONNECT_INITIAL_ADMIN_EMAIL` and `CNGCONNECT_INITIAL_ADMIN_PASSWORD`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
