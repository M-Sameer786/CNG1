@echo off
setlocal
cd /d "%~dp0"
echo === CNGConnect Windows setup ===
where node >nul 2>nul || (echo ERROR: Install Node.js from https://nodejs.org/ and reopen this file.& pause & exit /b 1)
where pnpm >nul 2>nul || (echo Installing pnpm...& npm install -g pnpm)
if not exist .env (copy .env.example .env >nul & echo Created .env. Edit it and set your PostgreSQL password before continuing.& notepad .env & pause & exit /b 0)
echo Installing project packages...
pnpm install
if errorlevel 1 (echo Package installation failed. Read the error above.& pause & exit /b 1)
echo.
echo Next: ensure PostgreSQL is running and database cngconnect exists.
echo Then run: pnpm db:push
pause
