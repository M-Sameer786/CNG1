import { existsSync, readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import { resolve } from "node:path";

const rootDir = resolve(import.meta.dirname, "..");
const localEnv = {};
const envPath = resolve(rootDir, ".env");

if (existsSync(envPath)) {
  for (const line of readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator < 0) continue;
    const key = trimmed.slice(0, separator).trim();
    const value = trimmed
      .slice(separator + 1)
      .trim()
      .replace(/^['"]|['"]$/g, "");
    if (key) localEnv[key] = value;
  }
}

const sharedEnv = {
  ...process.env,
  ...localEnv,
  NODE_ENV: process.env.NODE_ENV ?? "development",
};
const packageManager = process.platform === "win32" ? "pnpm.cmd" : "pnpm";
const services = [
  {
    name: "API",
    args: ["--filter", "@workspace/api-server", "run", "dev"],
    env: { PORT: sharedEnv.API_PORT ?? "5000" },
  },
  {
    name: "Web",
    args: ["--filter", "@workspace/cngconnect", "run", "dev"],
    env: {
      PORT: sharedEnv.WEB_PORT ?? "5173",
      BASE_PATH: "/",
      API_PORT: sharedEnv.API_PORT ?? "5000",
    },
  },
];

const children = services.map(({ name, args, env }) => {
  const child = spawn(packageManager, args, {
    cwd: rootDir,
    env: { ...sharedEnv, ...env },
    stdio: "inherit",
    shell: process.platform === "win32",
  });
  child.on("exit", (code, signal) => {
    if (signal) process.stderr.write(`${name} stopped (${signal}).\n`);
    else if (code !== 0)
      process.stderr.write(`${name} stopped with exit code ${code}.\n`);
  });
  return child;
});

let shuttingDown = false;
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  for (const child of children) child.kill(signal);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));