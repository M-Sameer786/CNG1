import { existsSync, rmSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const userAgent = process.env.npm_config_user_agent ?? "";
if (!userAgent.startsWith("pnpm/")) {
  console.error("Please install this project with pnpm, not npm or yarn.");
  process.exit(1);
}
for (const name of ["package-lock.json", "yarn.lock"]) {
  const file = resolve(root, name);
  if (existsSync(file)) rmSync(file);
}
