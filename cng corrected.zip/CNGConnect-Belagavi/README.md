# CNGConnect Belagavi

A web app for finding CNG stations in and around Belagavi, managing multiple driver vehicles, recording supplier-confirmed refuels, and managing station updates through driver, supplier, and administrator panels. Seeded station availability is demonstration data, not a live feed. Some coordinates are approximate and should be checked before relying on navigation.

## Run on Windows (VS Code / PowerShell)

### 1. Install the prerequisites

- Install **Node.js 22 LTS or newer supported Node.js 20.11+** from https://nodejs.org/ and reopen PowerShell.
- Install pnpm by running `npm install -g pnpm` in PowerShell. Confirm with `node -v` and `pnpm -v`.
- Install **PostgreSQL 14 or newer** from https://www.postgresql.org/download/windows/. During installation, remember the password for the `postgres` user and keep port `5432`.

### 2. Create the database

Open **SQL Shell (psql)** from the Start menu, connect to the local server, and run:

```sql
CREATE DATABASE cngconnect;
```

If the database already exists, do not create it again.

### 3. Set the database password

In the project folder, copy `.env.example` and name the copy `.env`. Edit `.env` and replace `postgres` in the password portion of `DATABASE_URL` with the password you chose during PostgreSQL installation. Example format:

```dotenv
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/cngconnect
API_PORT=5000
WEB_PORT=5173
CNGCONNECT_PAYMENT_MODE=test
```

Do not include angle brackets around the password. If your password contains URL-special characters, URL-encode them.

### 4. Install packages and create tables

Open this folder in VS Code. Choose **Terminal → New Terminal** and make sure the terminal is in the folder containing this README and `package.json`. Run these commands one at a time:

```powershell
pnpm install
pnpm db:push
```

If `pnpm install` reports that build scripts were ignored, run `pnpm approve-builds`, approve `esbuild` if listed, then run `pnpm install --no-frozen-lockfile` again.

### 5. Start the project

```powershell
pnpm dev
```

Wait for the API and Vite to start, then open **http://localhost:5173** in your browser. Keep the terminal open while using the app. Press `Ctrl+C` to stop.

## Demo logins

- Administrator: `admin@cngconnect.demo` / `Belagavi@123`
- Customer: `driver@cngconnect.demo` / `Driver@123`
- Supplier: `supplier@meghagas.demo` / `MeghaGas@123`

These credentials are only for local demonstration.

## Demo stock and availability

All seeded stations have illustrative stock values, clearly marked in the app as sample data. The app derives each demo station's availability from its stock: `0 kg` means unavailable, `1–100 kg` means running low, and more than `100 kg` means available. Changing the stock in the supplier panel recalculates the status when the update is published.

These numbers are for demonstrating the feature only. They do not come from Megha Gas or a live station feed, and they do not decrease over time on their own. Non-demo stations keep their reported/manual availability.

## Vehicles, refuels, and test payment

- Sign in as a driver and open **Your vehicles** to save multiple vehicles. CNG fitment is an explicit driver-reported field; the vehicle category never implies compatibility.
- Open a station or **Fuel activity**, select the vehicle currently being refuelled, and record the refuel request. The assigned supplier enters the actual dispenser quantity in **Supplier operations**.
- Supplier confirmation snapshots the current station price and approved 5–10% discount, calculates the bill on the server, and deducts the confirmed amount from recorded stock once in the same database transaction. Repeated confirmation requests cannot deduct stock again.
- A driver can print the resulting receipt from **Fuel activity**. Admins can see recent transactions and test-mode totals in **Administration → Fuel reports**.
- In local development, `CNGCONNECT_PAYMENT_MODE=test` enables a server-side signed test simulator. It records `TEST PAID` and does not contact a payment network or move real money. This is not a production payment-gateway integration. Before accepting real payments, connect a payment provider, store its sandbox/production credentials in Replit Secrets or a private `.env`, and implement its server-side order/callback verification.
- Station prices and discounts are not invented or seeded. A supplier must report a current price before drivers can submit a refuel request. The sample station values remain clearly marked as demo data.

## Verify the local demo workflow

1. Sign in as the demo driver, add a vehicle, and explicitly choose **Factory-fitted CNG** or **Retrofitted CNG**. Vehicles marked “Not confirmed” cannot be used for a refuel request.
2. In a second browser session, sign in as the demo supplier. Select the assigned station, report a current price and stock in the availability desk, and choose an approved discount (0%, 5%, 7.5%, or 10%).
3. Back in the driver session, select that vehicle and station under **Fuel activity**, then record a request.
4. In the supplier session, enter the actual kg reading from the dispenser and confirm it. Check the bill, discount, and remaining station stock.
5. In the driver session, refresh history, complete the **test payment**, and print the receipt. Repeating the supplier confirmation should return a conflict and leave stock unchanged.
6. Sign in as the admin and open **Fuel reports** to review the recorded transaction.

`pnpm db:push` updates the existing PostgreSQL database from the Drizzle schema. The equivalent SQL is included at `lib/db/migrations/0001_driver_vehicles_and_fuel.sql` for environments that apply reviewed SQL migrations instead.

## Common errors

- **ECONNREFUSED localhost:5432**: PostgreSQL is not running, or its port is different. Open Windows Services and start the PostgreSQL service, then retry `pnpm db:push`.
- **password authentication failed**: correct the password in `.env`.
- **DATABASE_URL missing**: make sure `.env` is in the project root beside `package.json`, not inside `artifacts`.
- **Cannot find native binding** for Rollup, Lightning CSS, or Tailwind Oxide: this project is configured to allow the Windows x64 native packages. Run `pnpm install` again from the project root.
- **`pnpm` or `node` is not recognized**: install Node.js, reopen PowerShell, then run `npm install -g pnpm`. Do not use `pip install pnpm`.

## Phone access

Connect the phone and computer to the same Wi-Fi and open `http://COMPUTER-IP:5173` on the phone, replacing `COMPUTER-IP` with the computer's local IPv4 address. The computer firewall may need to allow ports 5173 and 5000.
